from thread import *
from threading import *
import threading, sys, os
import socket,argparse,errno
import math

from safeSend import *

from random import choice
from time import sleep

# GLOBAL DATA

parser = argparse.ArgumentParser(description='Server for Universe')
parser.add_argument('-n', '--numhosts', type=int, help='number of hosts', required=True)
parser.add_argument('-p', '--port', type=int, help='port to listen on', default=31000)
parser.add_argument('-f', '--forcestrip', type=bool, help='force strip division of universe', default=False)
parser.add_argument('-u', '--numuni', type=int, help='number of universes', required=True)
parser.add_argument('-m', '--matrixwidth', type=int, help='dimensions of matrix', required=True)
parser.add_argument('-q', '--quiet', help='be quiet', action='store_true')
args=parser.parse_args()

clientModifyingStateLock = threading.Lock()
clientcountinglock = threading.Lock()
hostData = dict()
BUFFER_SIZE = 1024  
clients = []
threads = []
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
hostCount = dict()
hostCountCV = Condition()
hostCount['connected'] = 0 # number of connected hosts: 0
universes = [] # addresses of all the universes
init = 1
numHosts = args.numhosts
numUniverses = args.numuni
matrixSize = args.matrixwidth
quiet = args.quiet
strips = args.forcestrip
cellInfo = [[0 for y in range(matrixSize)] for x in range(matrixSize)] # matrix holding all of the cells. will be populated with addrs of hosts.
hostcheckin = 0


class connThread(threading.Thread):
  def __init__(self, conn, addr):
    threading.Thread.__init__(self)
    self.conn = conn
    self.addr = addr

  def run(self):
    clientThread(self.conn, self.addr)

class checkThread(threading.Thread):
  def __init__(self):
    threading.Thread.__init__(self)

  def run(self):
    threadCheck()

def threadCheck():
  while True:
    sleep(4)
    for t in threads:
      if not t.isAlive():
        python = sys.executable
        for c in clients:
          try:
            c[0].send(prepsend("KILL YOURSELF\n"))
          except:
            pass
        s.close()
        sleep(2)
        os.execl(python, python, * sys.argv)

def prepsend(instring):
  strlen = len(instring)
  numlen = len(str(strlen))
  return str(numlen)+str(strlen)+instring
  
def clientThread(conn, addr):
  conn.send(prepsend('SUP.\n'))
  identified = False
  # inititalize data for this host
  clientModifyingStateLock.acquire()
  hostData[addr] = dict()
  clientModifyingStateLock.release()

  buf = clientBuffer()
  go = True

  while go:
    try:
      numlen = int(conn.recv(1))
      strlen = int(conn.recv(numlen))
      data = conn.recv(strlen)
      if not quiet:
        print "from client " + str(addr) + ": " + data

      data = data.strip() # remove whitespace and linebreaks from end

      resp = doCommand(data, addr, buf)
      if (not (resp is None)) and (str(resp) != "None"):
        if not quiet:
          print [addr, resp]
        conn.send(prepsend(resp + '\n'))
    except socket.error, e:
      if e[0] == errno.EPIPE:
        print "Disconnected Client" 
        conn.close()
        go = False

  print 'done'

class clientBuffer:
  mybuf = ""
  def set(this, data):
    this.mybuf = data
  def get(this):
    return this.mybuf

def doCommand(data, addr, buf):
  # handles commands that come in from clients. 
  returnmsg = None # response to this command

  #############
  # response codes. all negative values are errors
  # all clients should probably ignore lines that don't start with + or -?
  # -000: invalid command
  # -001: invalid id type
  # -002: already used id
  # +001: succeeded, id as uni
  # +002: succeeded, id as vis

  commands = { # dict containing all of the information about commands. add keyvalue pairs to this to add new commands.
      'id': {
        'function': cmdId, # REQUIRED. name of the function to call for this command
        'numargs': 1, # OPTIONAL (0). number of ADDITIONAL arguments this command has
        'needslock': True, # OPTIONAL (False).  whether this command modifies global state
        'helptext': "identifies this client as either a vis(ualization) or uni(verse simulator). ", # printed as help text
        'usage': "id [uni|vis]"
        },
      'status': {
        'function': cmdStatus
        },
      'cells': {
        'function': cmdCells,
        'helptext': "tells you what cells are assigned to you."
        },
      'whohas': {
        'function': cmdWhoHas,
        'helptext': "query who owns cell x,y",
        'usage': "whohas x y",
        'numargs': 2
        },
      'bs': {
        'function': cmdDump
        },
      'getgridsize': {
        'function': cmdGetGridSize,
        'helptext': 'get grid size',
        'usage': 'getgridsize'
        },
      'nc': {
        'function': commandString,
        'numargs': 1,
        'helptext': 'get command string for initial run',
        'usage': 'nc [uni|vis]'
        },
      'READY': {
        'function': readyStepIncrement,
        'helptext': 'Sent when done copying robot vector',
        'needslock': True,
        'usage': 'READY'
        },
      'DGR': {
        'function': stepIncrement,
        'helptext': 'Sent when done copying robot vector',
        'needslock': True,
        'usage': 'DGR'
        },
      'DUS': {
        'function': stepIncrement,
        'helptext': 'Sent when done updating sensor',
        'needslock': True,
        'usage': 'DUS'
        },
      'DUP': {
        'function': stepIncrement,
        'helptext': 'Sent when done updating pose',
        'needslock': True,
        'usage': 'DUP'
        },
      'DBT': {
        'function': stepIncrement,
        'helptext': 'Sent when done updating pose',
        'needslock': True,
        'usage': 'DBT'
        },
      }
  cmd = data.split(' ')

  if cmd[0] in commands.keys(): # check if this is a valid command
    info = commands[cmd[0]]
    if len(cmd) == info.get('numargs', 0) + 1:
      if info.get('needsLock', False):
        clientModifyingStateLock.acquire()
      returnmsg = info['function'](cmd, addr, buf) # call the function
      if info.get('needsLock', False):
        clientModifyingStateLock.release()
    else:
      return "invalid number of args for", cmd[0], ", needs", info['numargs']
  else:
    returnmsg = "-000 invalid command\n" + printHelp(commands) + '\n'
    # TODO: print help

  return str(returnmsg)

def cmdId(cmd, addr, buf):
  if not 'type' in hostData[addr]: # only allow a client to identify itself once
    if cmd[1] == 'uni':
      #this host is a universe, init it as such
      hostData[addr]['type'] = 'uni'
      hostData[addr]['cells'] = []
      hostCountCV.acquire()
      universes.append(addr)
      hostCountCV.notify()
      hostCountCV.release()
      
      # do other stuff here?
      # maybe add to a global list of universes.
      print'Client at ',addr,'identified as a ',hostData[addr]['type']
      return '+001 succeeded id as uni'
    elif cmd[1] == 'vis':
      hostData[addr]['type'] = 'vis'
      print hostData
      print'Client at ',addr,'identified as a ',hostData[addr]['type']
      return '+002 succeeded id as vis'
    else:
      return '-001 error - not valid id type'
  else:
    return "-002 error - already identified as " + hostData[addr]['type']

def stepIncrement(cmd, addr, buf):
  global hostcheckin
  clientcountinglock.acquire();
  hostcheckin = hostcheckin + 1

  #print cmd[0], hostcheckin
  if hostcheckin == numUniverses:
    hostcheckin = 0

    if cmd[0] == 'DGR':
      for c in clients:
        try:
          c[0].send(prepsend("UPE\n"))
        except:
          print "error sending UPE to ", c
          pass
    elif cmd[0] == 'DUP':
      for c in clients:
        try:
          c[0].send(prepsend("UBT\n"))
        except:
          print "error sending UBT to ", c
          pass
    elif cmd[0] == 'DBT':
      for c in clients:
        try:
          c[0].send(prepsend("USN\n"))
        except:
          print "error sending USN to ", c
          pass
    elif cmd[0] == 'DUS' :
      for c in clients:
        try:
          c[0].send(prepsend("GRA\n"))
        except:
          print "error sending GRA to ", c
          pass
  clientcountinglock.release();
  return None

def readyStepIncrement(cmd, addr, buf):
  global hostcheckin
  clientcountinglock.acquire();
  hostcheckin = hostcheckin + 1

  #print cmd[0], hostcheckin
  if hostcheckin == numHosts:
    hostcheckin = 0

    for c in clients:
      try:
        c[0].send(prepsend("GRA\n"))
      except:
        print "error sending GRA to ", c
        pass
  clientcountinglock.release();
  return None

def cmdStatus(cmd, addr, buf):
  status = ''
  for ad in hostData.keys():
    status += 'host at ' + str(ad) + '\n'
    status += '\t' + str(hostData[ad]) + '\n'

  status += 'universes: ' + str(universes) + '\n'
  return status

def cmdCells(cmd, addr, buf):
  cells = ''
  for c in hostData[addr]['cells']:
    cells += str(c[0]) + ',' + str(c[1]) + '\n'
  return cells

def cmdWhoHas(cmd, addr, buf):
  x = int(cmd[1])
  y = int(cmd[2])
  ip = cellInfo[x][y][0]
  port = cellInfo[x][y][1]
  return ip

def cmdDump(cmd, addr, buf):
  out = ''
  for i in range(50000):
    out += str(i) + '\n'
  return out

def cmdGetGridSize(cmd, addr, buf):
  return matrixSize

def commandString(cmd, addr, buf):
  return "-p 1000 -d -q -u200 -z0"

def printHelp(commands):
  help = ''
  for c in commands.keys():
    com = commands[c]
    help += com.get('usage', c)+'\n' # print usage or command name
    help += '\t' + com.get('helptext', 'no help text.') + '\n'
    help += '\tnumber of args: ' + str(com.get('numargs', 0)) + '\n'
    help += '\tlocks server state: ' + str(com.get('needslock', False)) + '\n'
    #help += '\t' +  + '\n'
  return help

def assignSquares(unis, mSize):
  global strips
  # assign (in hostData) which universes own which squares.
  uniNum=int(len(unis))
  splitSize=(mSize*mSize)/uniNum
  uniRoot = int(math.sqrt(uniNum))
  targetHost = 0
  normalSplit = True  ##possibly replace this with a check to see if the number of 

  #normal cell assigning method splits map into columns of cells
  #these columns are assigned to a given host
  if ((uniNum % uniRoot != 0) or (uniNum < 4) or strips):
  #if normalSplit: 
    u=0
    count=0
    for x in range(mSize):
      for y in range(mSize):
        if ((targetHost >= ((u+1) * splitSize)) and (u < uniNum-1)):
          u+=1
        cellInfo[x][y] = unis[u]
        hostData[unis[u]]['cells'].append((x,y))
        targetHost+=1
    print cellInfo
  
  #modified cell assigning method splits map into equal squares
  #absolutely needs host count that has an integer square root
  #and benefits cell division that 
  else:
    splitMatrix = int(math.ceil(math.sqrt((mSize*mSize)/uniNum)))
    xmin=0
    xmax=0
    ymin=0
    ymax=0

    # create a matrix based on the number of hosts
    for h in range(uniRoot):
      for ha in range(uniRoot): 
  
        #create x range
        xmin = h*splitMatrix
        xmax = (h+1)*splitMatrix

        #extend x range to catch extra squares on edges
        if (h+1 == uniRoot) and (xmax < mSize):
          xmax = mSize


        ymin = ha*splitMatrix
        ymax = (ha+1)*splitMatrix

        #extend y range to catch extra squares on edges
        if (h+1 == uniRoot) and (xmax < mSize):
          xmax = mSize

        #print "cellset ", xmin, xmax, ymin, ymax
        for x in range(xmin,xmax):    
            for y in range(ymin,ymax):
              #print x, y
              cellInfo[x][y] = unis[targetHost]
              hostData[unis[targetHost]]['cells'].append((x,y))
        targetHost += 1

    
  
def main():
  TCP_IP = ''  # This computer's IP address
  TCP_PORT = args.port  # This computer's port

  s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) # allow reusing same address
  s.bind((TCP_IP, TCP_PORT))
  s.listen(1)

  ct = checkThread()
  ct.start()

  while hostCount['connected'] < numHosts:
    print "Currently have", hostCount['connected'], "hosts connected, waiting for", numHosts, "total."
    try:
      conn, addr = s.accept()
    except:
      pass

    print "New client at", addr
    hostCount['connected'] += 1
    x = connThread(conn, addr)
    threads.append(x)
    x.start()
    clients.append((conn, addr)) # keep track of all of the conns

  hostCountCV.acquire()
  while len(universes) < numUniverses:
    # wait until there are as many unis as we expect.
    print "universes: " + str(len(universes))
    hostCountCV.wait()

  clientModifyingStateLock.acquire()
  assignSquares(universes, matrixSize)
  clientModifyingStateLock.release()

  sleep(1) # THIS IS BAD

  try:
    for c in clients:
      c[0].send(prepsend("CELLSASSIGNED\n"))
  except:
    pass
    
  sleep(5)

  #
  #while 1:
  #  if init == 1:
  #    data = conn.recv(BUFFER_SIZE)
  #    if not data: break
  #    print "CLIENT INIT: ", data
  #    conn.send("ACCEPTED")
  #    init = 0
  #  else:
  #    data = conn.recv(BUFFER_SIZE)
  #    if not data: break
  #    print "CLIENT says: ", data
  #    var = raw_input("Response: ")
  #    conn.send(var)  # echo
  #conn.close()

  s.close()

if __name__ == "__main__":
    main()
