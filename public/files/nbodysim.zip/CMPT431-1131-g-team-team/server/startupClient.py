import socket
import os
import sys
import argparse
from os.path import expanduser
from thread import *
import subprocess as sp


def uniThread(command):
	os.system(command)


parser = argparse.ArgumentParser(description='Start Coordinated Universes')
parser.add_argument('-P', help='Set to equal the startupServer port')
parser.add_argument('-i', help='Set to the startupServer ip')

args = parser.parse_args()

port = int(args.P)
ipAddr = args.i

#connect to startup server
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

#connect to startup server
sock.connect((ipAddr, port))

runIndex = 0
#listen on port for commands
while True:
	commandIn = sock.recv(256)

	#if run universe then run universe thread so can still receive other commands

##add downloading universe program here
	if commandIn[:5].isdigit():
		print 'commandIn=', commandIn
		size = int(commandIn)
		sock.send('ok')
		f = open('universe', 'w')
		size = int(commandIn)
		print 'size=', size
		dataIn = ''
		dataIn2 = ''
		sock.send('ok')
		while len(dataIn) < size:
			dataIn2 = sock.recv(size)
			dataIn += dataIn2

		print 'exiting universe receive'
		print 'made file'
		print 'size =', size
		f.write(dataIn)
		f.close()

	elif commandIn[:10] == './universe':
		print 'uni commandIn=', commandIn
		#runIndex += 1
		uniCommand = commandIn
		uniCommand = uniCommand.split(' ')
		sp.Popen(uniCommand)
		#timeCommand = '/usr/bin/time -o rt/rt' + str(runIndex) + ' ' + commandIn
		#timeCommand = timeCommand.split(' ')
		#sp.Popen(timeCommand)
		#start_new_thread(uniThread, (uniCommand, ))

	elif 'get' in commandIn:
		commandList = commandIn.split(' ')
		f = open(commandList[1], 'r')
		dataOut = ''
		dataOut = f.read()
		size = str(len(dataOut))
		sock.send(size)
		sock.recv(64)
		sock.sendall(dataOut)
		print 'sent ' + commandList[1]
		f.close()

	elif commandIn == 'get output':
		f = open('output', 'r')
		dataOut = ''
		dataOut = f.read()
		size = str(len(dataOut))
		sock.send(size)
		sock.recv(64)
		sock.sendall(dataOut)
		print 'sent output'
		f.close()

	elif commandIn == 'exit':
		sock.close()
		sys.exit()

	elif len(commandIn) > 1:
		commandList = commandIn.split(' ')
		print 'commandIn=', commandIn
		try:
			retVal = sp.Popen(commandList)
			print retVal
		except:
			print 'Invalid command'
		#os.system(commandIn)
	
