import argparse
import os
import sys
import socket
from os.path import expanduser

parser = argparse.ArgumentParser(description='Start Universe.')

parser.add_argument("-u", help="Start as universe client.", action="store_true")
parser.add_argument("-v", help="Start as visualization client.", action="store_true")
parser.add_argument("-d", help="Delete old copy of universe and build from server.", action="store_true")
parser.add_argument("-i", help="Set the server IP address.")

args = parser.parse_args()

home = expanduser('~')
os.chdir(home)

# If the files don't exist, download them.
try:
    open('universe.tar.gz')
    os.chdir(home + '/universe/')
except:
    args.d = True

# If IP not given, DEMAND IT.
if (not args.i):
    print "Error: Please specify server IP address.\n"
    sys.exit(-1)

# If both types or no types specified, DEMAND EXACTLY ONE TYPE.
if (args.u and args.v) or (not args.u and not args.v):
    print "Error: Invalid argument.  Please specify ONE of -u or -v.\n"
    sys.exit(-1)

# If specified, delete old versions of code, redownload and rebuild.
if args.d:
    os.chdir(home)
    os.system('rm -rf universe/')
    os.system('rm -rf universe.tar.gz')
    os.system('wget http://www.jareddaley.com/files/universe.tar.gz')
    os.system('tar -xvzf universe.tar.gz')
    os.chdir(home + '/universe/')
    os.system('make')
else:
    os.chdir(home + '/universe/') 

# Create a socket.
try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
except:
    print "Error: Failed to create socket."
    sys.exit(-1)

# Connect to the specified server.
try:
    sock.connect((args.i, 12345))
except:
    print "Error: No such host."

# For a universe...
if args.u:
    reply = sock.recv(4096)             # Get SUP.              
    sock.sendall("nc uni")              # Send Command
    reply = sock.recv(4096)             # Get reply
    sock.close()                        # Close Socket
    reply = reply.strip(' \t\r\n\0')    # Trim Reply of Nulls
    os.system('./universe ' + reply)    # Run Universe

# For a visualization...
if args.v:
    reply = sock.recv(4096)             # Get SUP.
    sock.sendall("nc vis")              # Send Command
    reply = sock.recv(4096)             # Get Reply
    sock.close()                        # Close Socket
    reply = reply.strip(' \t\r\n\0')    # Trim Reply of Nulls
    os.system('./universe ' + reply)    # Run Universe
