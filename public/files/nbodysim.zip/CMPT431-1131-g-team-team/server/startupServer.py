import socket
import os
import sys
import re
import argparse
from thread import *
from os.path import expanduser
import time
import subprocess as sp
from testgen import *


parser = argparse.ArgumentParser(description='Start Coordinated Universes')
parser.add_argument('-P', help='Set listening port number', type=int)
parser.add_argument('-c', help='set number of universe clients', type=int)
parser.add_argument('-i', help='this ip')
parser.add_argument('-s', help='start client port', type=int)
parser.add_argument('-S', help='start server port', type=int)

args = parser.parse_args()

help = '''
	### Command descriptions ###
	
	h 			-> display this message
	send universe		-> send universe binary to clients
	resend 			-> send the previously entered command again
	exit 			-> close server and all client connections
	local 			-> brings up local command input
	get <clientFile> <fileToWrite> 		
				-> gets all <clientFile> files from connected 
				clients and concats them in <fileToWrite>


	(anything else) -> connected client executes command in shell
			
'''
#add commands for
# starting uniserver with default params
# starting uniserver with set params
# sending out universe binary

def clientThread(conn, addr):
	#client thread itself doesn't need to do anything
	pass

def uniServerThread(command):
	os.system(command)

#is time1 > time2
def timeGT(time1, time2):
    time1 = re.findall("[^\:\.]+", time1)
    time2 = re.findall("[^\:\.]+", time2)

    if len(time1) > len(time2):
        return True
    elif len(time1) < len(time2):
        return False
    else:
        for ind, x in enumerate(time1):
            if int(x) > int(time2[ind]):
                return True
            elif int(x) < int(time2[ind]):
                return False
            else:
                pass

    return False


	
#Setup server and listen for connections
uniSock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
uniSock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
print 'Uni Socket Created'

host = ''
port = args.P
clientsToConnect = args.c

try:
	uniSock.bind((host, port))
except socket.error, msg:
	print 'Socket bind failed' + str(msg)
	sys.exit()

uniSock.listen(100)
print 'Uni Socket Listening...'

socketList = []
command = ''

##########
testList = TestGen(args.i, args.s, args.S, clientsToConnect)

#accept client connections
while True:
	conn, addr = uniSock.accept()
	print 'Client connected from', addr

	socketList.append((conn, addr))
	print socketList
	print len(socketList)

	if len(socketList) == clientsToConnect:
		start_new_thread(clientThread, (conn, addr, ))
		while True:
			time.sleep(1)
			previousCommand = command
			command = raw_input('Enter Command:')

#			try:
#				print 'uniserver.poll()',uniserver.poll()
#			except:
#				pass
			#print socketList

			if command == 'send universe':
				uniBin = ''
				f = open('universe', 'rb')
				uniBin = f.read()
				f.close()
				size = str(len(uniBin))
				print 'size =', size
				for connection, address in socketList:
					connection.send(size)
					connection.recv(64)
					connection.sendall(uniBin)
					print 'sent to', address

			elif command == 'kserv':
				uniserver.kill()

			elif command == 'start default server':
				#if a server is up, kill it
				try:
					uniserver.kill()
				except:
					pass

				defaultServer = 'python server/uniserver.py -n 1 -u 1 -m 10 -p 12345'
				defaultServerCommand = defaultServer.split(' ')
				uniserver = sp.Popen(defaultServerCommand)
				#start_new_thread(uniServerThread, ('python server/uniserver.py -n 1 -u 1 -m 10 -p 12345', ))
			
			elif command == 'start server':
				#if a server is up, kill it
				try:
					uniserver.kill()
				except:
					pass

				serverCommand = raw_input('Enter server command:')
				serverCommand = serverCommand.split(' ')
				uniserver = sp.Popen(serverCommand)
				#start_new_thread(uniServerThread, (serverCommand, ))

			elif command == 't':
				#test 127.0.0.1 startPortNum numHosts/Clients
				
				#if a server is up, kill it
				try:
					uniserver.kill()
					print 'Killed existing server'
				except:
					pass
				#

				commandPair = testList.nextCommands()
				
				#print commandPair

				serverCommand = commandPair[0].split(' ')
				print 'servercommand = ', serverCommand
				universeCommand = commandPair[1]
				print 'universeCommand = ', universeCommand

				uniserver = sp.Popen(serverCommand)

				time.sleep(1)

				for connection, address in socketList:
					connection.send(universeCommand)

			#elif time command
			#  /usr/bin/time -o <time file> ./universe ...

			#new get command syntax   get <file on client> <file to write to>
			elif 'get' in command:
				commandList = command.split(' ')
				print commandList
				for connection, address in socketList:
					connection.send('get ' + commandList[1])
					size = int(connection.recv(64))
					print 'size =', size
					dataIn = ''
					dataIn2 = ''
					connection.send('ok')
					numBytesRecv = 0
					while len(dataIn) < size:
						dataIn2 = connection.recv(size)
						dataIn += dataIn2
						#print len(dataIn)

					dataIn = dataIn+"\n"
					#print 'dataIn=',dataIn
					f = open(commandList[2], 'a')
					f.write(dataIn)
					f.close()

#			elif command == 'get output':
#				for connection, address in socketList:
#					connection.send(command)
#					size = int(connection.recv(64))
#					print 'size =', size
#					dataIn = ''
#					dataIn2 = ''
#					connection.send('ok')
#					numBytesRecv = 0
#					while len(dataIn) < size:
#						dataIn2 = connection.recv(size)
#						dataIn += dataIn2
#						#print len(dataIn)
#					dataIn = dataIn+"\n"
#					#print 'dataIn=',dataIn
#					f = open('allOutput', 'a')
#					f.write(dataIn)
#					f.close()

			elif command == 'local':
				localCommand = raw_input('Enter Local Command:')
				os.system(localCommand)

			elif command == 'resend':
				for connection, address in socketList:
					connection.send(previousCommand)

			elif command == 'h':
				print help

			else:
				for connection, address in socketList:
					connection.send(command)

			if command == 'exit':
				sys.exit()
