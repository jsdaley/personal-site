from safeSend import *

lorem = """Lorem ipsum dolor sit amet.
consectetur adipiscing elit.
Vestibulum quis velit ut dui condimentum mollis eu sed lorem.
Nullam bibendum nunc et risus gravida nec eleifend magna aliquet.
Nunc purus lectus.
mattis sed rutrum non.
ornare quis risus.
Pellentesque dolor enim.
vehicula vel cursus et.
dictum eget diam.
Integer vestibulum nulla ante.
Suspendisse porta leo ac dolor ornare ullamcorper.
Vivamus pharetra.
nulla quis dictum gravida.
ipsum mauris facilisis lorem.
eget suscipit sem arcu id felis.
Nunc a nisi sed arcu iaculis ullamcorper non vel nunc.
Nunc lobortis faucibus lectus.
at fermentum velit scelerisque et.
Aliquam ipsum urna.
accumsan a blandit non.
adipiscing accumsan nibh.
Proin id velit diam.
sit amet molestie quam.
Cras convallis leo eget eros sollicitudin ac aliquet ligula aliquam.
Suspendisse malesuada convallis orci.
Curabitur tempus.
nibh eu auctor pharetra.
lorem felis ornare sem.
et pulvinar diam libero nec nibh."""


class dummyConn:
  datain = []
  def send(this, data):
    print "|" + data + "|"
    print "received", len(data), "characters"
    if data[-1] != '.':
      print "LAST CHARACTER IS NOT A PERIOD: MAYBE BROKEN LINE?"
    this.datain.append(data)
  def toString(this):
    string = ''
    for i in this.datain:
      if len(string) > 0:
        string += '\n'
      string += i
    return string

conn = dummyConn()


safeSend(lorem, conn, 128)

res = conn.toString()

PRINTRESULT = False
if PRINTRESULT:
  print "==== below: data ===="
  print lorem
  print "==== resulting string ===="
  print res


if lorem == res:
  print "GOOD"
else:
  print "FAILED"

print "orig:", len(lorem), ", res:", len(res)
