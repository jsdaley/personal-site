#server

import socket
import sys
from thread import *
import re


mapping = []


def clientThread(conn,  addr):
    #sending message when new client connects
    conn.send('***Welcome to server***\n')

    while True:
        conn.send('\n Enter some stuff:')
        data = conn.recv(1024)
        
        #echo data sent to server back to client
        reply = 'reply from server...' + data
        print 'received from client on port ' + str(addr[1]) + ' --> ' + data, 
        if not data:
            break
        
        #add grid coords to list of coordinates with portNum
        if 'gridCoord' in data:
            mapping.append((addr[0], addr[1],  re.split(':|\r|\n',  data)[1]))
        
        print 'mapping =',  mapping
        
        if 'disconnect' in data:
            print 'received disconnect from client at : ' + str(addr)
            print 'removing mapping entry...'
            for tuple in mapping:
                print tuple
                if addr[0] == tuple[0] and addr[1] == tuple[1]:
                     mapping.remove(tuple)
            break
    
        conn.sendall(reply)
    
    print 'Closing connection with client at : ' +str(addr)
    conn.close()


#create a socket
s = socket.socket(socket.AF_INET,  socket.SOCK_STREAM)
print 'Socket created'

#associate the socket with a port
host = ''   #can be left blank on server side
port = int (sys.argv[1])

try:
    s.bind((host, port))
except socket.error,  msg:
    print 'Socket bind failed. Error : ' + str(msg[0]) + ' Message ' + msg[1]
    sys.exit()

print 'Socket bind successful at :'
print s.getsockname()
#accept 'call' from client
#number of hosts that need to request the server at once...not total number of hosts...
listenNum = 5
s.listen(listenNum)
print '\nSocket listening'

#now communicate with client
while True:
    #wait for connection
    conn, addr = s.accept()
    print 'New client connected at',  addr

    #read string from client ( this example assumes that the message will be
    #short enough that one recv() is enough), and make multiple copies (to show
    #the need for the 'while" loop on the client side)

    start_new_thread(clientThread, (conn, addr, ))

# # # # For a single client connection
#
#    conn.send('welcome to the server!!!\n')
#    
#
#    while True:
#        conn.send('type stuff:')
#        
#        data = conn.recv(1024)
#        #concat data with itself??
#        
#        returnMessage = 'reply from server...' + data
#        confirmMessage = 'received -->> ' + data
#
#        print confirmMessage, 
#        #wait for the go-ahead signal from the keyboard ( to demonstrate that
#        #recv() at the client will block until server sends
#
#        if 'quit' in data:
#            quitControl = True
#            break
#
#    #    z = raw_input()
#    #    if z == 'hello':
#    #        print 'world'
#    #        break
#
#        #now send...send or sendall?
#        conn.sendall(returnMessage)
#        #conn.send(data)
#    
#    if quitControl:
#        print 'received quit/kill signal from client'
#        break



#close the connection
conn.close()

