from time import sleep

def safeSend(data, conn, bufsize):
  # make sure no lines are split across buffers.
  data += '\0'
  if len(data) < bufsize: # no problem, the data fits in our buffer.
    conn.send(data)
  else:
    # TODO: DEAL WITH IT
    lastend = 0
    done = False
    while not done:
      #print "data[",lastend,":",bufsize+lastend,"]"
      buf = data[lastend:bufsize+lastend]
      #print "buf: ", buf
      bufEnd = buf.rfind('\n')
      if bufEnd == -1: # no more newlines? okay, where's null?
        #print "no more newline"
        bufEnd = buf.rfind('\0')
        done = True

      tosend = buf[:bufEnd]

      if bufEnd == -1 and bufNull == -1:
        print "BUFFER NOT BIG ENOUGH TO FIT A LINE"

      conn.send(tosend)
      lastend += bufEnd + 1
      #print "set lastend:", lastend
      sleep (0.3)


    #pos = data[(bufsize * n):rfind('\n')]
