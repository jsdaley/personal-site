import pygame,sys,math,argparse,struct
from pygame.locals import *
import thread
import time
from threading import *
import threading, sys, os
import socket,argparse,errno
from os.path import expanduser
import random
from copy import copy, deepcopy

# Helper Functions
########################

def prepsend(instring):
  strlen = len(instring)
  numlen = len(str(strlen))
  return str(numlen)+str(strlen)+instring

def hexToFloat(hexnum):
  return float.fromhex(hexnum)

def robotToPointlist(robot):
  x = pointToPixel(robot[0])
  y = pointToPixelY(robot[1])

  robotangle = math.radians(160)

  xa = pointToPixel(robot[0]+ (robotsize * math.cos(robot[2] + robotangle)))
  ya = pointToPixelY(robot[1]+ (robotsize * math.sin(robot[2] + robotangle)))

  xb = pointToPixel(robot[0]+ (robotsize * math.cos(robot[2] - robotangle)))
  yb = pointToPixelY(robot[1]+ (robotsize * math.sin(robot[2] - robotangle)))

  return [(x,y), (xa, ya), (xb, yb)]

def pointToPixel(point):
  return (point - focus[0]) / worldScale  * windowWidth * zoom + (windowWidth/2)

def pointToPixelY(point): # use to convert absolute positions in the world to pixels
  return windowHeight - (((point - focus[1])) / worldScale * windowHeight * zoom + (windowHeight/2))

def sizeToPixels(point):
  return point / worldScale  * windowWidth * zoom + (windowWidth/2)

def pixelToPoint(xy):
  x = xy[0]
  y = xy[1]
  ptx = (x - windowWidth/2.0) / zoom / windowWidth * worldScale + focus[0]
  pty = -1 * ((y - windowWidth/2.0) / zoom / windowWidth * worldScale - focus[1])
  #pty = worldScale - ((y - windowHeight/2.0) / zoom / windowHeight * worldScale + focus[1])
  return (ptx, pty)

def loadRobotsFromFile(path):
  start = pygame.time.get_ticks()
  robotsFromFile = []
  with open(path) as inputFile:
    for line in inputFile:
      line = line.strip();
      vals = line.split(', ')
      robotsFromFile.append((float(vals[0]),float(vals[1]),float(vals[2])))
  if(args.time):
    print("loadrobots took: " + str(pygame.time.get_ticks() - start) + "ms")
  return robotsFromFile

def loadRobotsFromNetwork(netBuffer):
  start = pygame.time.get_ticks()
  robotsFromVector = []
  for line in netBuffer:
    line = line.strip();
    vals = line.split(',')
    robotsFromVector.append((float(vals[0]),float(vals[1]),float(vals[2])))
  if(args.time):
    print("loadrobots took: " + str(pygame.time.get_ticks() - start) + "ms")
  return robotsFromFile


def loadCellPopulationsFile(path, gridSects):
  linePopulations = []
  wholePopulation = []
  with open(path) as inputFile:
    for line in inputFile:
        line = line.strip();
        vals = line.split(' ')
        for i in range(gridSects):
          linePopulations.append((int)(vals[i]))
        wholePopulation.append(linePopulations)
        linePopulations = []        
  return wholePopulation

def loadCellPopulations(gridS, cellP):
  linePopulations = []
  wholePopulation = []
  for i in range(gridS):
    for j in range(gridS):
      linePopulations.append(cellP[(j*gridS)+i])
    wholePopulation.append(linePopulations)
    linePopulations = []
  return wholePopulation


#Colorized takes single color value and used HSV math
#To turn it into a spectrum of colors
###############################
def colorized (color, colormax):
  hsvhue = (color*255/colormax)
  # case 0
  if ((hsvhue >= 0) and (hsvhue < 43)):
    return (0, 0, ((hsvhue/43.0)*255))

  # case 1
  elif ((hsvhue >= 43) and (hsvhue < 86)):
    return (0, ((hsvhue-42)/43.0)*255, 255)

  # case 2
  elif ((hsvhue >= 86) and (hsvhue < 128)):
    return (0, 255, ((128-hsvhue)/43.0)*255)
  
  # case 3
  elif ((hsvhue >= 128) and (hsvhue < 171)):
    return (((hsvhue-128)/43.0)*255, 255, 0)

  # case 4
  elif ((hsvhue >= 171) and (hsvhue < 214)):
    return (255, ((214-hsvhue)/43.0)*255, 0)

  # case 5  
  elif ((hsvhue >= 214) and (hsvhue <= 255)):
    return (255, 0, ((hsvhue-214)/43.0)*255)

  # case 6
  elif ((hsvhue >= 255) and (hsvhue <= 298)):
    return (255, ((hsvhue-255)/43.0)*255, 255)

  # case 7
  else:
    return (255, 255, 255)  


# Argument Handling
########################

parser = argparse.ArgumentParser(description='Visualization for universe')
parser.add_argument("-i",'--ip', help="Set the server IP address.", default="127.0.0.1")
parser.add_argument("-p", '--port', type=int, help="Set the server port number", default=12345)
parser.add_argument("-P", '--uport', type=int, help="Set universe port number", default=12346)
parser.add_argument("-s", '--scale', type=int, help="world scale", default=1)
parser.add_argument("-t", '--time', help="print the time it takes to do some things", action="store_true")
parser.add_argument("-o", '--pop', type=int, help="set population size", default=100)
parser.add_argument("-m", '--matrix', type=int, help="set matrix side size", default=10)

args = parser.parse_args()
  
# Initialization Section
########################

pygame.init()
fpsClock = pygame.time.Clock()

windowWidth = 640
windowHeight = 640

ipAddress = args.ip
port = args.port
uport = args.uport

population = args.pop
totalGridSections = args.matrix
totalGridSectionf = 1.0 * totalGridSections
totalGridSectionsq = population/(1.0*totalGridSections)

#matrix of bools for enabling cells
cellEnabled = [[False for y in range(totalGridSections)] for x in range(totalGridSections)]

worldScale = args.scale 

singleGridW = worldScale/totalGridSectionf
singleGridH = worldScale/totalGridSectionf

windowSurfaceObj = pygame.display.set_mode((windowWidth,windowHeight))
pygame.display.set_caption('Universe Visualization')

whiteColor = pygame.Color(255,255,255)
robotColor = pygame.Color(255,255,255)
msgColor = pygame.Color(0,0,255)

totalpop = 1000
tempColorA = (0,255,0)
tempColorB = (0,255,255)

robotsize = 0.05

popLock = threading.Lock()
botLock = threading.Lock()

ipDict = dict()


robots = []

cellPop = []
cellPop2D = []

#intialize the visualization by generating a spectrum on load
for i in range (totalGridSections):
  for j in range (totalGridSections):
    cellPop.append(j)

cellPop2D = loadCellPopulations(totalGridSections, cellPop)


#so the histogram colors make some sense, we adjust the average
#based on whether the population is smaller or larger than the 
#number of grid/matrix squares.
#should the population be even smaller than root of the total
#number of gridsquares, the population itself is used as the basis
#for the histogram
if population > totalGridSectionsq:
  averagePop = population/totalGridSectionsq
else:
  if population > totalGridSections:
    averagePop = population/totalGridSections
  else:
    averagePop = population


zoom = 1
focus = (worldScale / 2.0, worldScale / 2.0)

# Graphics Section
####################
def graphics():
  global zoom
  global focus
  global cellPop2D
  global cellEnabled
  global popLock
  global botLock
  global robots

  msg = 'message'
  font = pygame.font.Font('DroidSans.ttf', 16)

  counter = 0
  cellPop2DLocal = []
  robotsLocal = []
  sprite = pygame.image.load('s.png')
  ship = pygame.image.load('t.png')
  spriteToggle = False

  while True:
    windowSurfaceObj.fill(whiteColor)

    
    #Lock and copy bots
    #botLock.acquire()
    #robotsLocal = deepcopy(robots)
    #botLock.release()    
  
    #Lock and copy cells
    popLock.acquire() 
    cellPop2DLocal = deepcopy(cellPop2D)
    popLock.release()
    
    for i in range(totalGridSections, -1, -1):
      for j in range (totalGridSections):   
          windowSurfaceObj.fill(colorized(cellPop2DLocal[i-1][j], averagePop), 
           (pointToPixel(j*singleGridW),
            pointToPixelY(i*singleGridH),
            sizeToPixels(singleGridW),
            sizeToPixels(singleGridH)))

    robotSurface = pygame.Surface((windowWidth,windowHeight), pygame.SRCALPHA, 32)
    robotSurface = robotSurface.convert_alpha()
    start = pygame.time.get_ticks()
    botLock.acquire()
    for robot in robots:
      xVal = int(math.floor(pointToPixel(robot[0])))
      yVal = int(math.floor(pointToPixelY(robot[1])))
      if spriteToggle:
        spriteAngled = pygame.transform.rotozoom(sprite, math.degrees(robot[2]), zoom * robotsize)
        windowSurfaceObj.blit(spriteAngled, (xVal, yVal))
      else:
        #spriteAngled = pygame.transform.rotozoom(ship, math.degrees(robot[2]), zoom * 0.1)
        #windowSurfaceObj.blit(spriteAngled, (xVal, yVal))
        #pygame.draw.circle (robotSurface, robotColor, (xVal, yVal), 1, 0)
      	pygame.draw.polygon(robotSurface, robotColor, robotToPointlist(robot), 1)
    botLock.release()

    if(args.time):
      print("update took " + str(pygame.time.get_ticks() - start) + "ms")
    if spriteToggle == False:
      robotRect = robotSurface.get_rect()
      robotRect.topleft = (0,0)
      windowSurfaceObj.blit(robotSurface, robotRect)

    msgSurfaceObj = font.render(msg, False, msgColor)
    msgRectObj = msgSurfaceObj.get_rect()
    msgRectObj.topleft = (10,20)
    windowSurfaceObj.blit(msgSurfaceObj,msgRectObj)
    
    # handle events
    for event in pygame.event.get():
      if event.type == QUIT:
        pygame.quit()
        sys.exit()
      elif event.type == MOUSEBUTTONUP:
        if event.button == 1:
          focus = pixelToPoint(event.pos)
        if event.button == 3:
          pointTemp=pixelToPoint(event.pos)
          cx = int(math.floor(pointTemp[0]/singleGridW))
          cy = int(math.floor(pointTemp[1]/singleGridH))
          try:
            cellEnabled[cx][cy] = not cellEnabled[cx][cy]
          except:
            pass
        if event.button in (4, 5):
          # scroll
          if event.button == 4:
            zoom = zoom + 0.1
          elif event.button == 5:
            if zoom > 1:
              zoom = zoom - 0.1
            else:
              zoom = 1
              focus = (worldScale / 2.0, worldScale / 2.0) #reset
      elif event.type == MOUSEMOTION:
        msg = str(event.pos) + ", pt: " + str(pixelToPoint(event.pos))
      elif event.type == KEYDOWN:
        #press z to reset the zoom
        if event.key == K_z:
          zoom = 1
          focus = (worldScale / 2.0, worldScale / 2.0) #reset

        #press x to enable/disable sonic
        if event.key == K_s:
          spriteToggle = not spriteToggle
        
        #press a to invert cell selection
        if event.key ==K_a:
          for i in range(totalGridSections):
            for j in range(totalGridSections):
              cellEnabled[i][j] = not cellEnabled[i][j]

    pygame.display.flip()
    fpsClock.tick(60)

# Networking Section
####################

def translateRecvMessage(sock):
  numlen = int(sock.recv(1))
  strlen = int(sock.recv(numlen))
  buf = ''
  while len(buf) < strlen:
    buf += sock.recv(strlen)
  return buf

# Returns a tuple of form (CellPop_Socket, Query_Socket, Query_SocketLock)
def getSocket(ipAddr, port):
  if ipAddr in ipDict:
    return ipDict[ipAddr]
  else:
    tupl = []

    try:
      sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    except:
      print "Error: Failed to create socket."
      sys.exit(-1)
    # Connect to the specified server.
    try:    
      sock.connect((ipAddr, port))
      tupl.append(sock)
    except:
      print "Error: Cannot connect to " + str(ipAddr) + " " + str(port) + "\n"
      sys.exit(-1)

    newLock = threading.Lock()
    tupl.append(newLock)
    ipDict[ipAddr] = tuple(tupl)
    return ipDict[ipAddr]


# Create a socket.
def networking(ipAddr, port):
  global cellPop2D
  global poplock
  global robots
  global uport

  cellPopped = []
  cellPopped2D = []
  rawRobotData = ''
  robotsFromNetwork=[]

  #draw info in graphics thread...

  #if zooming in, then request the actual robot data from the necessary universe(s)
  ##send HUH request here...this is being implemented above...should be the get populations loop above instead
  ##

  #trying to connect to uni before uni started???
  #time.sleep(0.1)
  try:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print "Networking Started"
  except:
    print "Error: Failed to create socket."
    sys.exit(-1)
  # Connect to the specified server.
  try:    
    sock.connect((ipAddr, port))
       
    print "Socket Connected"
  except:
    print "Error: Cannot connect to " + str(ipAddr) + " " + str(port) + "\n"
    sys.exit(-1)

  sock.send(prepsend("id vis"))
  dataIN = translateRecvMessage( sock )
  print dataIN
  dataIN = translateRecvMessage( sock )
  print dataIN


# wait for CELLSASSIGNED
  while dataIN != 'CELLSASSIGNED\n':
    dataIN = translateRecvMessage (sock)
    print "in", dataIN

  ipList = []
  hostList = []
  #loop through all all gridsquares and get ips...must wait until all universes have connected and have been assigned cells
  for i in range(totalGridSections):
    for j in range(totalGridSections):
      sock.send(prepsend("whohas " + str(i) + " " + str(j)))
#      print "whohas", str(i), str(j)
      dataIN = translateRecvMessage( sock )
      dataIN = dataIN[:-1]
      ipList.append((i, j, dataIN))
      if dataIN not in hostList:
        hostList.append(dataIN)
  
  print 'ipList =', ipList
  print 'hostList =', hostList

  sock.send(prepsend("READY"))

  #start cellthreads for cell population updating
  cellthreads = []
  time.sleep(1)
  for host in hostList:
    try:
      hostSock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    except:
      print "Error: Failed to create socket."
      sys.exit(-1)
    # Connect to the specified server.

    try:    
      hostSock.connect((host, uport))
    except:
      print "Error: Cannot connect to " + str(host) + " " + str(uport) + "\n"
      sys.exit(-1)

    ct = threading.Thread(target=cellNetwork, args=(hostSock,))
    cellthreads.append(ct)
  
  for thread in cellthreads:
    thread.start()


##Looping for threading
  while True:
    #think there's an issue with listening as well...was sometimes getting a pile of update messages rather than one at a time...
    listening = True
    while listening:
      #print 'listening'
      dataIN = translateRecvMessage(sock)
      dataIN = dataIN.strip()
      
      #print "IN NET FUNCTION: " + dataIN
      if dataIN == 'USN':
        listening = False
        print 'listening false'
    #if receives 'USN' from server, then get information from all the hosts

    #once know all ips, request cell population info from all universes after each update
    #get info from each uni at each step

    for ip in ipList:
      ipTuple = getSocket(ip[2], uport)
      uniSock = ipTuple[0]
      uniLock = ipTuple[1]

        #send "HUH gridPos"
        #print 'sending HUH', ip[0], ip[1]
      if cellEnabled[ip[0]][ip[1]]:
        uniSock.send(prepsend('HUH '+ str(ip[0]) + ' ' + str(ip[1])))
        data = translateRecvMessage(uniSock)

        if data != 'e':
          replies = data.splitlines();
          for item in replies:
            vals = item.split()
            #print vals
            try:
              robotsFromNetwork.append((hexToFloat(vals[0]),hexToFloat(vals[1]),hexToFloat(vals[2])))
            except:
              print vals
 
    ##Thread Code For Networking
    ##1. Acquire lock.
    ##2. Copy Locally Saved Data into Global Variable
    ##3. Release Lock.
    ##4. Clear local variables for reuse

    botLock.acquire()
    robots = deepcopy(robotsFromNetwork)
    botLock.release()
    robotsFromNetwork = []

    ##print 'network lock release'
    ##print "network cellPop2D "


# Cell Networking Section 
# Under construction pending additions to universe.
# Launched by main networking section
#########################
def cellNetwork(sock):
  global cellPop2D
  global popLock
  global uport

  sock.send(prepsend('CELLPOPALL'))

  while 1:
    start = sock.recv(1)

    if start != '':
      numlen = int(start)
      strlen = int(sock.recv(numlen))
      data = sock.recv(strlen)

      cellData = data.split()

      popLock.acquire()
#      print cellData
      cellPop2D[int(cellData[0])][int(cellData[1])] = int(cellData[2])
      popLock.release()


# Threading/Launch Section for main threads.
####################
threads = []

t = threading.Thread(target=graphics, args=())
threads.append(t)

t = threading.Thread(target=networking, args=(ipAddress, port ))
threads.append(t)

print "Starting Visuals"
for thread in threads:
  thread.start()
