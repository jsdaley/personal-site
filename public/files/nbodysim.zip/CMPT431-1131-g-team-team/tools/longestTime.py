import time
import re
import argparse

parser = argparse.ArgumentParser(description="Gets the longest time in a time file for Universe")
parser.add_argument("file", type=str, help="The file to read")

args = parser.parse_args()
fn = args.file

x = open(fn, 'rb')
y = x.readlines()

times = []

#is time1 > time2
def timeGT(time1, time2):
    time1 = re.findall("[^\:\.]+", time1)
    time2 = re.findall("[^\:\.]+", time2)

    if len(time1) > len(time2):
        return True
    elif len(time1) < len(time2):
        return False
    else:
        for ind, x in enumerate(time1):
            if int(x) > int(time2[ind]):
                return True
            elif int(x) < int(time2[ind]):
                return False
            else:
                pass

    return False

for line in y:
    if line[0:1] == "0i":
        pass
    elif line[0:1] == "Co":
        pass
    else:
        larr = line.split()
        for piece in larr:
            if piece.endswith('elapsed'):
                times.append(piece.rstrip('elapsed'))
            else:
                pass

longTime = "0:00.00"

for x in times:
    if timeGT(x, longTime):
        longTime = x
    else:
        pass

print longTime
