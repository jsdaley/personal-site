#!/bin/sh

cat _commandList | sed "s:/usr/bin/time -o rt/:all:" | sed "s: ./universe -p :,:" | sed "s/ -m /,/" | sed "s/ -s /,/" | sed "s/ -f /,/" | sed "s/ -r /,/" | sed "s/ -i.*$//"
