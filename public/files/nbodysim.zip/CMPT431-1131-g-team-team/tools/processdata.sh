#!/bin/bash

# Converts a folder of data files (allrt#) into a csv format that can be copied into a spreadsheet.

for i in `ls allrt*`
do 
  grep -Ev "(Command|inputs|^$)" $i | sed "s/elapsed.*$//" | sed "s/user /,/" | sed "s/system /,/" | sed "s/:/,/" | sed "s/^/$i,/" >> merged
done
  
