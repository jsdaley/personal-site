#Universe Test Generator
#Karl Olson
########################

import argparse
import math



class TestGen:
  uniClientCommandList = []
  uniServerCommandList = []
  stepNum = 0


  def __init__(self, ipAddr, port, clients):
    # variable definitions
    ########################
    clientRootFloat = math.sqrt(clients)
    clientRootInt = (int)(math.floor(clientRootFloat))
    populations = [1000, 200000, 1000000]
    worldSizes = [50, 100, 200]
    viewRadii = [30, 90, 180, 270]
    viewRanges = [0.5, 1, 2]
    

    # if the number of hosts is a perfect square, optimize number of grid divisions
    # to provide for maximum performance
    ########################
    if (clientRootFloat - clientRootInt) != 0:
      gridSizes = [90, 120, 150]
    else:
      gridSizes = [10 * clientRootInt, 20 * clientRootInt, 30 * clientRootInt] 

    # Cycle through populations, gridSizes, worldSizes, viewRadii and viewRanges
    # to test 324 different combinations of those elements.
    #####################
    for population in populations:
      for gridSize in gridSizes:
        for worldSize in worldSizes:
          for viewRadius in viewRadii:
            for viewRange in viewRanges:
              self.uniClientCommandList.append("./universe -p" + str(population) + " -m" + str(gridSize) + " -s" + str(worldSize) + " -f" + str(viewRadius) + " -r" + str(viewRange) + " -i" + str(ipAddr) + " -P"+ str(port))
              port += 1
              self.uniServerCommandList.append("python server/uniserver.py -q -m" + str(gridSize) + " -n" + str(clients) + " -u" + str(clients) + " -p12345")


  def printAllCommands(self):
    print self.uniClientCommandList
    print self.uniServerCommandList

  def printClientCommands(self):
    print self.uniClientCommandList

  def printServerCommands(self):
    print self.uniServerCommandList

  def nextCommands(self):
    ret = (self.uniServerCommandList[self.stepNum], self.uniClientCommandList[self.stepNum])
    self.stepNum += 1
    return ret


        
  
