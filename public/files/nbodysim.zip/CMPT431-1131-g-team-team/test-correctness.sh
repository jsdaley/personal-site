#!/bin/sh

./universe -u 3000 -f 90 -s 1 -z0 -d -q -t
diff -q output correctness/1.ref

./universe -u 500 -p 2000 -f 180 -s 2 -d -z0 -q -t
diff -q output correctness/2.ref

./universe -u 600 -p 600 -f 30 -s 5 -z0 -d -q -t
diff -q output correctness/3.ref

echo "If any lines say that files differ, the tests failed."
