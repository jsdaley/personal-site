#!/bin/sh

#  deep-correctness.sh
#  Created by Karl Olson on 3/27/13.

ipaddr="142.58.35.xxx"
port=12346

for population in 100 1000 50000 100000 200000 500000 1000000
do
  for viewradius in 30 90 270
  do
    for gridsize in 30 40 50 60 90 120 150
    do
      for worldsize in 10 25 50 100 200 300
      do
        echo "./universe -u 20 -p $population -f $viewradius -s $worldsize -z0 -t -m $gridsize -i$ipaddr -P$port"
        port=`echo "$port + 1" | bc`
    done
  done
done
