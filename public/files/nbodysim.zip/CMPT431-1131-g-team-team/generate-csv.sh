#!/bin/sh

TIMEFORMAT=%R
# always include the following opts
GLOBALOPTS="-d -z 0 -u 500"

STARTTIME=`date +%b-%d-%H-%M`

for ms in 20 30 40 # matrix size
do
	for ws in  5 8 10 15 20
	do
		for fov in 270
		do
			#for pop in 100 300 500 700 900 1100 1300 1500
			for pop in 3000 5000 7000 9000 11000 13000 15000 20000 25000 30000
			#for pop in 50 100 150 200 250
			do
				#record pop size

				echo "running ws:$ws ms:$ms fov:$fov pop:$pop"

				# do three trials. this is implemented poorly!
				m1=`( time ./universe $GLOBALOPTS -p $pop -f $fov -s $ws -m $ms; ) 2>&1 1>/dev/null`
				m2=`( time ./universe $GLOBALOPTS -p $pop -f $fov -s $ws -m $ms; ) 2>&1 1>/dev/null`
				m3=`( time ./universe $GLOBALOPTS -p $pop -f $fov -s $ws -m $ms; ) 2>&1 1>/dev/null`

				mmean=`echo "scale=10; ($m1+$m2+$m3)/3" | bc`
				mvar=`echo "scale=10; ($m1^2 + $m2^2 + $m3^2)/3 - $mmean^2" | bc`
				echo "$ws,$ms,$fov,$pop,$mmean,$mvar" >> data-$STARTTIME.csv


			done
		done
	done
done
