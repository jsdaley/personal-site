new-universe
============

CMPT 431 Project for Improved Universe Algorithm

A simple n-body simulator for exploring distributed systems.

Authors: Richard Vaughan, Mike Lim, Jared Daley, Karl Olson, Cody Hart, Tim Mckenney 2013
License: GNU GPL v3 or later (applies to all files in this repo).

## Pre-requirements

### Ubuntu (Tested on Ubuntu 11.10, 12.04 and 12.10)

<pre>
sudo apt-get install build-essential cmake freeglut3-dev 
</pre>

Optional: 

<pre>
sudo apt-get install libxi-dev libxmu-dev
</pre>

## Compile

```bash
[in code directory]
make
```

The Make script is a wrapper around [CMake](http://www.cmake.org/). 
