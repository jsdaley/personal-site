/****
universe.cc
version 4

Original by: Richard Vaughan

Group Team Team
===============
Michael Lim
Karl Olson
Cody Hart
Tim McKenney
Jared Daley
****/

#include <assert.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#include <iostream>
#include <sstream>

#include "universe.h"

using namespace Uni;

const char* PROGNAME = "universe";

#if GRAPHICS
#ifdef __APPLE__
#include <glut/glut.h>
#else
#include <GL/glut.h> // OS X users need <glut/glut.h> instead
#endif
#endif


namespace Uni {

  ////////////////////////////
  // ** GLOBAL VARIABLES ** //
  ////////////////////////////

  bool need_redraw( true );
  double worldsize(1.0);
  std::vector<Robot> population( 100 );
  
	std::vector< std::vector<Cell> > cellgrid;
  
  uint64_t updates(0);
  uint64_t updates_max( 0.0 );
  bool paused( false );
  int winsize( 600 );
  int displaylist(0);
  bool show_data( true );
  bool gridlines( false );
  bool boundingbox( false );
  bool show_robots( true );
  bool show_full_robots ( false);
  unsigned int sleep_msec( 50 );
  int matrix_size( 10 );
  int matrix_size_sq ( 100 );
  bool _outputToFile(false);

  int howmanyhuhs(0);

  char* port = "12346";

  bool firstUpdateCell(true);
  void (*callback)( Robot& r, void* user );

  Network _network;
  int sv_con_socket;
  int cli_con_socket;
  char* ip_addr;

  std::vector< std::vector <bool> > _unownedCells;
  std::vector< std::vector <char*> > _otherUniverses;

  std::vector<Robot> _remotePop;
  std::vector<std::string> _newBots;
  std::vector<Robot*> _leavingBots;
  std::vector<Robot*> _availableBots;
  
  //switch for running through local subset of cells.
  std::vector < std::vector <bool> > gridset;
  
  
  //switch for using inner to outer cell addition in list building
  //see function Uni::CellsInBoundingBox for details
  bool optimizedlist(false);
  
  //additional globally useful information:
  int radius(1);  
  double cellsize(0.1);


  double lastseconds;
  
  //Threading Business.
  pthread_t * threads;
  int done = 0;
  int step = 0;
  pthread_mutex_t mutex_done = PTHREAD_MUTEX_INITIALIZER;
  pthread_cond_t cond_done = PTHREAD_COND_INITIALIZER;
  pthread_mutex_t mutex_step = PTHREAD_MUTEX_INITIALIZER;
  pthread_cond_t cond_step = PTHREAD_COND_INITIALIZER;
  
  pthread_mutex_t mutex_boundarycross = PTHREAD_MUTEX_INITIALIZER;

  pthread_mutex_t mutex_networksend = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_t mutex_uninetworksend = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_t mutex_queueing_new = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_t mutex_queueing_leaving = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_t mutex_modifypop = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_t mutex_openingSocket = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_t mutex_addingUnusedBot = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_t mutex_modifyRemotePop = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_t mutex_modifyUnownedCells = PTHREAD_MUTEX_INITIALIZER;
  pthread_mutex_t mutex_doingQueryRemoteCell = PTHREAD_MUTEX_INITIALIZER;
  
  pthread_mutex_t mutex_clientqueue = PTHREAD_MUTEX_INITIALIZER;
  pthread_cond_t cond_clientqueue = PTHREAD_COND_INITIALIZER;
  std::vector<int> clientqueue;
  std::vector<connection> connections;

  pthread_mutex_t mutex_cellpopall = PTHREAD_MUTEX_INITIALIZER;
  pthread_cond_t cond_cellpopall = PTHREAD_COND_INITIALIZER;

  int numthreads;
  
  // network listening thread
  pthread_t listening;

  // Robot static members
  unsigned int Robot::pixel_count( 8);
  double Robot::range( 0.1 );
  double Robot::fov(  dtor(270.0) );
}

char usage[] = "Universe understands these command line arguments:\n"
"  -? : Prints this helpful message.\n"
"  -b draw bounding box for each robot\n"
"  -c <int> : sets the number of pixels in the robots' sensor.\n"
"  -d  Disables drawing the sensor field of view. Speeds things up a bit.\n"
"  -f <float> : sets the sensor field of view angle in degrees.\n"
"  -i <string> : Sets the IP address of the server.\n"
"  -j Enable optimized creation of cell list in the field of view. \n"
"  -k Don't draw robots. \n"
"  -m <int> : sets width and height of the matrix\n"
"  -n Draw gridlines. \n"
"  -p <int> : set the size of the robot population.\n"
"  -P <int> : sets the port for the client.\n"
"  -q : disables chatty status output (quiet mode).\n"
"  -r <float> : sets the sensor field of view range.\n"
"  -s <float> : sets the side length of the (square) world.\n"
"  -t output robot locations to a file\n"
"  -u <int> : sets the number of updates to run before quitting.\n"
"  -v draw triangle robots. \n"
"  -w <int> : sets the initial size of the window, in pixels.\n"
"  -z <int> : sets the number of milliseconds to sleep between updates.\n";

#if GRAPHICS
// GLUT callback functions ---------------------------------------------------

////////////////////////////
// ** STATIC FUNCTIONS ** //
////////////////////////////

// update the world - this is called whenever GLUT runs out of events
// to process
static void idle_func( void )
{
  Uni::UpdateAll();
  // possibly snooze to save CPU and slow things down
  if( Uni::sleep_msec > 0 )
    usleep( Uni::sleep_msec * 1e3 );
}

static void timer_func( int dummy )
{
  glutPostRedisplay(); // force redraw
}

// draw the world - this is called whenever the window needs redrawn
static void display_func( void )
{
  if( Uni::need_redraw )
  {
    Uni::need_redraw = false;
    
    glClear( GL_COLOR_BUFFER_BIT );
    
    if(gridlines){
      int i,j;
      for (i=0;i<matrix_size;i++){
        for(j=0;j<matrix_size;j++){
          cellgrid[i][j].Draw();
        }
      }
    }
    FOR_EACH( r, population )
    r->Draw();

    FOR_EACH( r, _remotePop )
    r->Draw();
    
    glutSwapBuffers();
    
    glFlush();
  }
  
  // cause this run again in about 50 msec
  glutTimerFunc( 50, timer_func, 0 );
}

static void mouse_func(int button, int state, int x, int y)
{
  if( (button == GLUT_LEFT_BUTTON) && (state == GLUT_DOWN ) )
  {
    Uni::paused = !Uni::paused;
  }
}

#endif // GRAPHICS

////////////////////////
// ** CONSTRUCTORS ** //
////////////////////////

Robot::Robot()
: pose(),
speed(),
color(),
pixels( pixel_count ),
callback(NULL),
callback_data(NULL),
cell(NULL),
unused(false),
remote(false)
{
  // until C++ supports array literals in the initialization list, we're forced to do this
  memset( pose, 0, sizeof(pose));
  memset( speed, 0, sizeof(speed));
  color[0] = 128;
  color[1] = 0;
  color[2] = 0;
}


Robot::Robot (float x_pos, float y_pos, float angle, int cx, int cy)
: pose(),
speed(),
color(),
pixels( pixel_count ),
callback(NULL),
callback_data(NULL),
cell(NULL),
unused(false),
remote(true)
{
  memset( pose, 0, sizeof(pose));
  memset( speed, 0, sizeof(speed));
  color[0] = 128;
  color[1] = 0;
  color[2] = 0;

  pose[0] = x_pos;
  pose[1] = y_pos;
  pose[2] = angle;

  callback = Uni::callback;

  SetCell(cx, cy); // locks
}
Network::Network()
{

}

////////////////////
// ** UNIVERSE ** //
////////////////////

/*
Function: Init
Purpose: Initializes the universe!

Params:
argc, argv - System arguments.
*/
void Uni::Init( int argc, char** argv )
{
  // seed random number generator with a constant
  srand48(0);
  
  bool quiet = false; // controls output verbosity
  
  int population_size = 100;

  // parse arguments to configure Robot static members
  int c;
  while( ( c = getopt( argc, argv, ":?tbdjklNnqvp:s:f:r:c:u:z:w:m:i:P:")) != -1 )
    switch( c )
  {
    case 'p':
      population_size = atoi( optarg );
      if( ! quiet ) printf( "[Uni] population_size: %d\n", population_size );
      population.resize( population_size );
      _remotePop.reserve(population_size);
      _newBots.reserve(population_size/2);
      _leavingBots.reserve(population_size/2);
      break;
      
    case 'm':
      matrix_size = atoi( optarg );
      if( ! quiet ) printf( "[Uni] matrix_size: %d\n", matrix_size );
      break;
      
    case 's':
      worldsize = atof( optarg );
      if( ! quiet ) printf( "[Uni] worldsize: %.2f\n", worldsize );
      break;
      
    case 'f':
      Robot::fov = dtor(atof( optarg )); // degrees to radians
      if( ! quiet ) printf( "[Uni] fov: %.2f\n", Robot::fov );
      break;

    case 'i':
      ip_addr = optarg; // server ip address
      if( ! quiet ) printf( "[Uni] Server ip address: %s\n", ip_addr );
      break;
      
    case 'P':
      Uni::port = optarg;
      if( ! quiet ) printf( "[Uni] listen_port: %s\n", Uni::port);
      break;
    case 'r':
      Robot::range = atof( optarg );
      if( ! quiet ) printf( "[Uni] range: %.2f\n", Robot::range );
      break;
      
    case 'c':
      Robot::pixel_count = atoi( optarg );
      if( ! quiet ) printf( "[Uni] pixel_count: %d\n", Robot::pixel_count );
      break;
      
    case 'u':
      updates_max = atol( optarg );
      if( ! quiet ) printf( "[Uni] updates_max: %lu\n", (long unsigned)updates_max );
      break;
      
    case 'z':
      sleep_msec = atoi( optarg );
      if( ! quiet ) printf( "[Uni] sleep_msec: %d\n", sleep_msec );
      break;
      
#if GRAPHICS
    case 'w': winsize = atoi( optarg );
      if( ! quiet ) printf( "[Uni] winsize: %d\n", winsize );
      break;
      
    case 'k': show_robots= false;
      if( ! quiet ) printf( "[Uni] No robots displayed. \n" );
      break;
      
    case 'v': show_full_robots= true;
      if( ! quiet ) printf( "[Uni] Display triangle robots. \n" );
      break;
#endif
    case 'd': show_data= false;
      if( ! quiet ) puts( "[Uni] hide data. \n" );
      break;
      
    case 'q': quiet = true;
      break;
      
    case 'j': optimizedlist = true;
      if (! quiet) puts ("[Uni] Inner to outer list generation enabled. \n");
      break;
      
    case 'n': gridlines = true;
      if (! quiet) puts ("[Uni] Display visual heatmap. \n");
      break;
      
    case 'b': boundingbox = true;
      break;
      
    case 't':
    {
      _outputToFile = true;
      if( ! quiet ) puts( "[Uni] Outputting to file to check accuracy. \n" );
    }
      break;
			
    case '?':
      puts( usage );
      exit(0); // ok
      break;
      
    default:
      fprintf( stderr, "[Uni] Option parse error.\n" );
      puts( usage );
      exit(-1); // error
  }
	
#if GRAPHICS
  // initialize opengl graphics
  glutInit( &argc, argv );
  glutInitWindowSize( winsize, winsize );
  glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA );
  glutCreateWindow( PROGNAME );
  glClearColor( 1.0,1.0,1.0,1.0 );
  glutDisplayFunc( display_func );
  glutTimerFunc( 50, timer_func, 0 );
  glutMouseFunc( mouse_func );
  glutIdleFunc( idle_func );
  glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );
  glEnable( GL_BLEND );
  glMatrixMode( GL_PROJECTION );
  glLoadIdentity();
  gluOrtho2D( 0,1,0,1 );
  glMatrixMode( GL_MODELVIEW );
  glLoadIdentity();
  glScalef( 1.0/worldsize, 1.0/worldsize, 1 );
  
  // define a display list for a robot body
  double h = 0.01;
  double w = 0.01;
  
  glPointSize( 0.5 );
  
  displaylist = glGenLists(1);
  
  glNewList( displaylist, GL_COMPILE );
  
  glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
  if (show_robots){
    if (show_full_robots){
      glBegin( GL_POLYGON );
      glVertex2f( h/2.0, 0 );
      glVertex2f( -h/2.0,  w/2.0 );
      glVertex2f( -h/2.0, -w/2.0 );
      glEnd();
    }
    else{
      glBegin (GL_POINTS);
      glVertex2f (h,w);
      glEnd();
    }
  }
  
  glEndList();
#endif // GRAPHICS

  //recalculate cellsize & radius in case anything has changed
  cellsize = worldsize / (double) matrix_size;
  radius = (int)ceil(Robot::range/(double)cellsize);
  matrix_size_sq = matrix_size*matrix_size;

  Gridify();

  /* Initiate connection with master server. */
  #if DISTRIBT

  _network = Network();

  // Server IP and port
  pthread_mutex_lock(&Uni::mutex_openingSocket);
  sv_con_socket = _network.openSocket(ip_addr, "12345");
  int optval = 1;
  setsockopt(sv_con_socket, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof optval);
  cli_con_socket = _network.startServer(Uni::port);
  pthread_mutex_unlock(&Uni::mutex_openingSocket);

  if (sv_con_socket < 0)
  {
    _network.error("ERROR can't create socket with server");
  }

  if (cli_con_socket < 0)
  {
    _network.error("ERROR can't create socket for listening");
  }

  pthread_mutex_lock(&mutex_networksend);
  if (_network.handshake(sv_con_socket) < 0)
  {
    _network.error("ERROR handshake fail");
  }
  pthread_mutex_unlock(&mutex_networksend);

  _network.sendMessage("cells", sv_con_socket);
  char* cellsbuffer = _network.rcvMessage(sv_con_socket);

  // HERE WE ALLOCATE THESE CELLS TO OUR UNIVERSE
  GridsetInitialize(cellsbuffer, strlen(cellsbuffer));

  free(cellsbuffer);

  // Start Thread for Listening for Clients
  pthread_create(&listening, NULL, Network::listenForConnections, &cli_con_socket);

  #endif
  
  threads = new pthread_t[matrix_size_sq];
  
  CreateThreads();

  pthread_mutex_lock(&Uni::mutex_modifyUnownedCells);
  _unownedCells.resize(matrix_size);

  for (int i = 0; i < _unownedCells.size(); i++)
  {
    _unownedCells[i].resize(matrix_size);
  }
  pthread_mutex_unlock(&Uni::mutex_modifyUnownedCells);

  _otherUniverses.resize(matrix_size);

  for (int i = 0; i < _otherUniverses.size(); i++)
  {
    _otherUniverses[i].resize(matrix_size);
  }

  ResetUnownedCellsArray();
  
  struct timeval start;
  gettimeofday( &start, NULL );
  lastseconds =  start.tv_sec + start.tv_usec/1e6;

  #if DISTRIBT
  pthread_mutex_lock(&mutex_networksend);
  _network.sendMessage("READY", sv_con_socket);
  char* buff = _network.rcvMessage(sv_con_socket);

  pthread_mutex_unlock(&mutex_networksend);

  if (strcmp(buff, "GRA\n") != 0)
  {
    printf("INVALID MESSAGE: %s\n", buff);
    exit(-1);
  }

  free(buff);
  #endif
}

/*
Function: ResetUnownedCellsArray
Purpose: Clears out the UnownedCellsArray.
*/
void Uni::ResetUnownedCellsArray()
{
  pthread_mutex_lock(&Uni::mutex_modifyUnownedCells);
  for (int i = 0; i < _unownedCells.size(); i++)
  {
    for (int j = 0; j < _unownedCells.size(); j++)
    {
	  if(gridset[i][j] == false){ // clear out cells we don't own
	  	  // this was updated, so clear the cellpop
	  	  cellgrid[i][j].cellpop.clear();
		  _unownedCells[i][j] = false;
	  }
    }
  }
  pthread_mutex_unlock(&Uni::mutex_modifyUnownedCells);
}

/*
Function: AddRemoteRobots
Purpose: Updates the sensor of each robot.  This is very complicated.  Read the
internal comments to get a sense of what this function does.
*/
void Uni::AddRemoteRobots(char* buffer, int cx, int cy)
{
  double x_pos, y_pos, angle = 0;

  char x_hex[30];
  char y_hex[30];
  char angle_hex[30];

  std::string input(buffer);
  std::string line;

  std::stringstream instream(input);
  while(std::getline(instream,line)){
    sscanf(line.c_str(), "%s %s %s", &x_hex, &y_hex, &angle_hex);
    x_pos = strtod(x_hex, NULL);
    y_pos = strtod(y_hex, NULL);
    angle = strtod(angle_hex, NULL);

    pthread_mutex_lock(&mutex_modifyRemotePop);
    _remotePop.emplace_back(x_pos, y_pos, angle, cx, cy); 
    pthread_mutex_unlock(&mutex_modifyRemotePop);
  }

}

/*
Function: QueueNewRobot
Purpose: Adds the robot to the queue of robots entering the system.  It's a
border guard.

Params:
r - the arriving robot
*/
void Uni::QueueNewRobot(char* newRobot)
{
  pthread_mutex_lock(&mutex_queueing_new);
  std::string str(newRobot);
  _newBots.push_back(str);
  pthread_mutex_unlock(&mutex_queueing_new);
}

/*
Function: QueueLeavingRobot
Purpose: Adds the robot to the queue of robots leaving the system.  It's a
border guard.

Params:
r - the departing robot
*/
void Uni::QueueLeavingRobot(Robot* r)
{
  pthread_mutex_lock(&mutex_queueing_leaving);
  _leavingBots.push_back(r);

  r->unused=true;

  char* msg = (char*) malloc (sizeof (char) * 256);
  int newsockfd;

  char* ip = Uni::GetCellOwnerIP(r->cell);
  connection* con;

  sprintf(msg, "NB %a %a %a %d %d\n", r->pose[0], r->pose[1], r->pose[2], r->cell->cx, r->cell->cy);

  pthread_mutex_lock(&Uni::mutex_openingSocket);
  con = _network.getSocket(ip);
  newsockfd = con->sfd;
  pthread_mutex_t * mutex_sock = &(con->conn_lock);
  pthread_mutex_unlock(&Uni::mutex_openingSocket);

  pthread_mutex_lock(mutex_sock);
  _network.sendMessage(msg, newsockfd);

  char* rcvbuffer = _network.rcvMessage(newsockfd);
  if(strncmp(rcvbuffer, "OK", 2) != 0){
    fprintf(stderr, "problem with NB ack");
    exit(-1);
  }
  free(rcvbuffer);

  pthread_mutex_unlock(mutex_sock);

  _availableBots.push_back(r); // add to the vector of unused bots


  free(msg);
  pthread_mutex_unlock(&mutex_queueing_leaving);
}

// Function to get the contents of a cell not
// owned by this host.
void Uni::QueryRemoteCell(Cell *cell, int x, int y)
{
  int newsockfd;

  char* queryBuffer = (char*) malloc (sizeof (char) * 256);
  sprintf(queryBuffer, "HUH %d %d\n", x, y);

  char* ip = Uni::GetCellOwnerIP(&(*cell)); // Locks mutex_networksend
  connection* con;

  pthread_mutex_lock(&Uni::mutex_openingSocket);
  // Establish a connection with the cell's owner.
  con = _network.getSocket(ip);
  newsockfd = con->sfd;
  pthread_mutex_t * mutex_sock = &(con->conn_lock);
  pthread_mutex_unlock(&Uni::mutex_openingSocket);

  // Ask the cell's owner for the buffer size.

  #if NETDEBUG
    fprintf(stderr, "HUH in thread %d\n", mutex_sock->__data.__owner);
  #endif

  pthread_mutex_lock(mutex_sock);
  _network.sendMessage(queryBuffer, newsockfd);
  char* robotDataBuffer = _network.rcvMessage(newsockfd);
  #if NETDEBUG
    fprintf(stderr, "HUH ACK (%s) in thread %d\n", robotDataBuffer, mutex_sock->__data.__owner);
  #endif
  pthread_mutex_unlock(mutex_sock);


  if(robotDataBuffer[0] != 'e'){
    // NOTE: THIS CALLS THE CELLPOP LOCK.
    Uni::AddRemoteRobots(robotDataBuffer, x, y); 
  }
  free(robotDataBuffer);

  free(queryBuffer);

  pthread_mutex_lock(&Uni::mutex_modifyUnownedCells);
  _unownedCells[x][y] = true;
  pthread_mutex_unlock(&Uni::mutex_modifyUnownedCells);
}

/*
Function: ClearRemotePopulation
Purpose: Clears out old positions of remote robots.
*/
void Uni::ClearRemotePopulation()
{
  _remotePop.clear();

  for (int i = 0; i < matrix_size; i++)
  {
    for (int j = 0; j < matrix_size; j++)
    {
      Cell c = cellgrid[i][j];

      if (gridset[i][j] == false)
      {
        c.cellpop.clear();
      }
    }
  }
}

/*
Function: GetCellOwnerIP
Purpose: Gets the IP address of an owner of a cell from our map.

Params:
c - The cell we want the owner of.
*/
char* Uni::GetCellOwnerIP(Cell* c)
{
  int x = c->cx;
  int y = c->cy;

  char* key = (char*) malloc (sizeof (char) * 256);
  char* ip;

  sprintf(key, "%d %d", x, y);

  char* tempBuffer = (char*) malloc (sizeof (char) * 256);

  // We do not know which universe owns this cell, so we
  // need to ask the master server to find out. This will
  // then be added to the unordered_map and stored for the
  // eternity of the program, so we don't have to ask the
  // master every single time.
  pthread_mutex_lock(&mutex_networksend);
  if (_otherUniverses[x][y] == NULL)
  {
    bzero(tempBuffer, (sizeof (char) * 256));
    strcpy(tempBuffer, "whohas ");
    strcat(tempBuffer, key);    

    _network.sendMessage(tempBuffer, sv_con_socket);
    char* buffer = _network.rcvMessage(sv_con_socket);

    buffer[strlen(buffer)-1] = '\0'; // get rid of newline

    _otherUniverses[x][y] = buffer;
  }
  pthread_mutex_unlock(&mutex_networksend);

  // Grab the ip address of the cell's owner.
  ip = _otherUniverses[x][y];

  free(key);
  free(tempBuffer);

  return ip;
}

/*
Function: UpdateAll
Purpose: Main process controlling all threads.
*/
void Uni::UpdateAll()
{
  // if we've done enough updates, exit the program
  if( updates_max > 0 && updates > updates_max )
  {
    if (_outputToFile)
    {
      OutputToFile();
    }
	  
    fprintf(stderr, "how many huhs: %d", howmanyhuhs);
    exit(1);
  }
  
  if( !paused )
  {
    // Wait for all threads to have copied cellpop
    SyncWait(1); 
    // get rid of robots we don't own
    pthread_mutex_lock(&mutex_modifyRemotePop);
    _remotePop.clear(); 
    pthread_mutex_unlock(&mutex_modifyRemotePop);
    // can clean this up while threads are doing UpdatePose since they won't need this array.
    ResetUnownedCellsArray(); 
    // Wait for all threads to have done UpdatePose
    SyncWait(3); 
    // Handle all of the robot boundary transitions.
    doNewBots();
    doLeavingBots();
    pthread_cond_broadcast(&cond_cellpopall); // notify all connected clients interested in cellpop of the updates.
    // Tell all the threads housekeeping is done
    SyncWait(2); 
    // Wait for all threads to be done UpdateSensor
    SyncWait(0); 
    
    need_redraw = true;
  }
  
  const int period = 10;
  
  if( updates % period == 0 )
  {
    struct timeval now;
    gettimeofday( &now, NULL );
    double seconds = now.tv_sec + now.tv_usec/1e6;
    double interval = seconds - lastseconds;
    printf( "[%d] FPS %.3f\r",(int)updates, period/interval );
    fflush(stdout);
    lastseconds = seconds;
  }
  
  ++updates;
}

/*
Function: OutputToFile
Purpose: Outputs the position of every robot across the network to a file.
*/
void Uni::OutputToFile()
{
  FILE * f;
  
  f = fopen("output", "w");
  
  FOR_EACH (r, population)
  {
    #if DISTRIBT
    if (!(r->unused))
    {
      fprintf(f,"%.6f,%.6f,%.6f\n", r->pose[0], r->pose[1], r->pose[2]);      
    }
    #else
    fprintf(f,"%.2f,%.2f,%.2f\n", r->pose[0], r->pose[1], r->pose[2]);   
    #endif
  }
  
  fclose(f);
}

/*
Function: CellToBuffer
Purpose: Converts a cell into something that can be sent over our network.

Params:
cx, cy - x,y coordinates of cell to put to message for network transport.
*/
char* Uni::CellToBuffer(int cx, int cy)
{
  pthread_mutex_t * mutex = &(cellgrid[cx][cy].mutex_cellpop);
  pthread_mutex_lock(mutex);
  int numbots = cellgrid[cx][cy].cellpop.size();
  int charsPerLine = 100; // was 70
  int minsize = 5;
  char* buf = (char*) malloc (sizeof (char) * numbots * charsPerLine + minsize);
  bzero(buf, sizeof (char) * numbots * charsPerLine + minsize);
  if(numbots == 0){
      buf[0] = 'e';
      pthread_mutex_unlock(mutex);
  	  return buf;
  }
  char* buf_lastpos = buf;
  std::size_t buf_remaining = (sizeof(char) * numbots * charsPerLine);

  FOR_EACH (r, cellgrid[cx][cy].cellpop)
  {
    Robot* robot = *r;
    int written_bytes = snprintf(buf_lastpos, buf_remaining, "%a %a %a\n",robot->pose[0], robot->pose[1], robot->pose[2]);
    if (written_bytes > 0){
      buf_lastpos += written_bytes;
      buf_remaining -= written_bytes;
    }
    else{
      fprintf(stderr, "problem with cell buffer, probably not big enough. exiting.");
      exit(1);
    }
  }
  #if NETDEBUG
	fprintf(stderr, "buffer:");
	fprintf(stderr, buf);
	fprintf(stderr, "bytes written: %d", (long)buf_lastpos - (long)buf);
  #endif

  pthread_mutex_unlock(mutex);
  return buf;
}

/*
Function: getCellPopulation
Purpose: Returns a buffer containing the population of a cell.

Params:
cx, cy - x,y coordinates of cell to put to message for network transport.
*/
char* Uni::getCellPopulation(int cx, int cy)
{
  char* buf = (char*) malloc (sizeof (char) * 256);
  bzero(buf, sizeof (char) * 256);

  sprintf(buf, "%d", cellgrid[cx][cy].cellpop.size());

  return buf;
}

/*
Function: doNewBots
Purpose: function to add cell incoming robots into population vector
*/
void Uni::doNewBots()
{
  pthread_mutex_lock(&mutex_queueing_new);
  //for all robot info in newBots, add it to population vector
  FOR_EACH( positions, _newBots ){
    double x_pos, y_pos, angle = 0;
    int new_cx, new_cy = 0;

    char x_hex[30];
    char y_hex[30];
    char angle_hex[30];

    char* nope[5];

    std::string newrobotinfo(*positions);
    sscanf(newrobotinfo.c_str(), "%s %s %s %s %d %d", &nope, &x_hex, &y_hex, &angle_hex, &new_cx, &new_cy);

    x_pos = strtod(x_hex, NULL);
    y_pos = strtod(y_hex, NULL);
    angle = strtod(angle_hex, NULL);
    
    Robot* recycledbot = _availableBots.back();
    _availableBots.pop_back();

    recycledbot->unused=false;

    recycledbot->pose[0] = x_pos;
    recycledbot->pose[1] = y_pos;
    recycledbot->pose[2] = angle;

    recycledbot->SetCell(new_cx, new_cy);
  }
  _newBots.clear();
  pthread_mutex_unlock(&mutex_queueing_new);
}

/*
Function: doLeavingBots
Purpose: function to delete bots leaving current client
*/
void Uni::doLeavingBots()
{
  _leavingBots.clear();
}

/*
Function: Gridify
Purpose: Sets up the cells on the grid, and initializes them for use with threads
(gives them their mutexes)
*/
void Uni::Gridify()
{
	int i,j;
  
	cellgrid.resize(matrix_size);
  
	#if DISTRIBT
  gridset.resize(matrix_size);
  #endif
  
	for (i=0;i<matrix_size;i++)
  {
		cellgrid[i].resize(matrix_size);

		#if DISTRIBT
    gridset[i].resize(matrix_size);
    #endif

		for(j=0;j<matrix_size;j++)
    {
			cellgrid[i][j] = Cell();
			Cell *c = &cellgrid[i][j];
			c->left = cellsize * i;
			c->bottom = cellsize * j;
			c->right = cellsize * (i+1);
			c->top = cellsize * (j+1);
      
			c->cx = i;
			c->cy = j;
      
			pthread_mutex_init(&(c->mutex_cellpop), NULL);
			pthread_mutex_init(&(c->mutex_cellquery), NULL);
      
			c->cellpop.reserve(population.size());
		}
	}
}

/*
Function: GridsetInitialize
Purpose: A function to define which cells are controlled by this particular 
instance of universe.

Params:
buffer - a list of x,y coordinates denoting position in the 2D grid of cells
bufsize - the size of buffer (for processing)
*/
void Uni::GridsetInitialize(char* buffer, int bufsize)
{
  int x,y;
  char* buff = (char*) malloc(sizeof (char) * bufsize+1);   //this needs to be the size of the incoming buffer
  char* cmd;

  bzero(buff, (sizeof (char) * bufsize+1));
  strncpy(buff, buffer, (sizeof (char) * bufsize)); // Copy the string into the allocated char array.

  cmd = strtok(buff,",\n");

   while ((cmd != NULL) && (*cmd != '\002'))
   {
      fprintf(stderr, "cmd: %s\n", cmd);

      x = atoi(cmd);
      cmd = strtok(NULL, ",\n");
      y = atoi(cmd);
      cmd = strtok(NULL, ",\n");
      fprintf(stderr, "xin: %d, yin: %d\n", x, y);
      // Assign the grid of the parsed location to true.
      gridset[x][y] = true;
   }
}

/*
Function: CellsInBoundingBox
Purpose: Gets the cells that a robot's range crosses over.

Params:
robot - the robot whose range we are checking
cells - a pointer to the vector which we populate with cells
*/
void Uni::CellsInBoundingBox(Robot * robot, std::vector<Cell*> * cells)
{
	int x,y;
	int cx,cy; // x and y mod matrix_size (for wraparound)
  int mincx, mincy, maxcx, maxcy;
  mincx = (int) floor(robot->fovbox[2] / cellsize);
  mincy = (int) floor(robot->fovbox[3] / cellsize);
  maxcx = (int) floor(robot->fovbox[0] / cellsize);
  maxcy = (int) floor(robot->fovbox[1] / cellsize);
  
 if (optimizedlist)
 {
    //optimized list building that starts at the center of the possible fov and 
    //moves outward by adding an outer loop which keeps tracks of an expanding 
    //radius.  i is the current radius of squares being added to the list, which
    //maxes out at the field of view

    //x and y location take care of the offset which cell the robot is in
    int xloc =  (int) floor(robot->pose[0] / cellsize);
    int yloc =  (int) floor(robot->pose[1] / cellsize);

    for (int i = 0; i <= radius; i++)
    {
      for(x = -i+xloc; x <= i+xloc; x++)
      {
        for(y = -i+yloc; y <= i+yloc; y++)
        {
          //if x is equal to the max or min of the current radius, every cell in
          //that row is new and so should be added to the list.
          if ((x==(-i+xloc)) || (x==(i+xloc)))
          {
            // add matrix_size first in case we have to loop in the negative direction.
            cx = (x+matrix_size) % matrix_size;
            cy = (y+matrix_size) % matrix_size;
            cells->push_back(&cellgrid[cx][cy]);
          }
          
          //if x isn't equal
          else
          {
            // same code as in the if
            cx = (x+matrix_size) % matrix_size;
            cy = (y+matrix_size) % matrix_size;
            cells->push_back(&cellgrid[cx][cy]);

            // skip cells in the row we've already add by going to the end of the row
            y=i+yloc;
            
            //same code as in the if
            cx = (x+matrix_size) % matrix_size;
            cy = (y+matrix_size) % matrix_size;
            cells->push_back(&cellgrid[cx][cy]);
          }
        }
      }
    }
  }
  
  else 
  {
    //simple x,y double loop list building
    for(x = mincx; x <= maxcx; x++)
    {
      for(y = mincy; y <= maxcy; y++)
      {
        // add matrix_size first in case we have to loop in the negative direction.
        cx = (x+matrix_size) % matrix_size; 
        cy = (y+matrix_size) % matrix_size;
        cells->push_back(&cellgrid[cx][cy]);
      }
    }
  }
  
}

/*
Function: CreateThreads
Purpose: Creates the threads based on the number given in system args.
*/
void Uni::CreateThreads(){
  
  //threads for each square on the map
  #if !DISTRIBT
  numthreads = matrix_size_sq;
  for(int x=0; x<matrix_size; x++)
  {
    for(int y=0; y<matrix_size; y++)
    {
      Cell *c = &(cellgrid[x][y]);
      pthread_create( &threads[(x*matrix_size) + y], NULL, Uni::ThreadEntry, (void*)c);
    }
  }
  
  //threads only for those in the gridset
  #else
  for(int x=0; x<matrix_size; x++)
  {
    for(int y=0; y<matrix_size; y++)
    {
      if (gridset[x][y] == true)
      {
        numthreads++;
        Cell *c = &(cellgrid[x][y]);
        pthread_create( &threads[(x*matrix_size) + y], NULL, Uni::ThreadEntry, (void*)c);
      }
    }
  }
  #endif
}

/*
Function: ThreadEntry
Purpose: The starting point for our threads.  Does each step and then syncs.

Params:
id - The id number of the thread.
*/
void* Uni::ThreadEntry(void* id){
  Cell * c = (Cell*)id;
  
  while(1){
    // copy the vector for cellpop so it can be overwritten by updatepose
    std::vector<Robot*> cp(c->cellpop); 
    // Tell main thread that this thread is done updating cellpop
    Sync(1); 
    
    FOR_EACH( r, cp ){
      Robot * ro = *r;
      ro->UpdatePose();
    }

    // Tell main thread that this thread is done updating pose.
    Sync(3); 
    // Wait for main thread to do housekeeping after UpdatePoses
    Sync(2); 

    FOR_EACH( r, c->cellpop ){
      Robot * ro = *r;
      ro->UpdateSensor();
    }
    
    FOR_EACH( r, c->cellpop )
    {
      Robot * ro = *r;
      Robot &b = *ro;
      ro->callback( b, ro->callback_data);
    }

    // Tell main thread that we have finished UpdateSensor (and updating the 
    // callbacks)
    Sync(0);
  }
}

/*
Function: Sync
Purpose: Allows threads to tell main process that it's done a step.

Params:
stepnum - The number of the step that the process finished.
*/
void Uni::Sync(int stepnum){
  pthread_mutex_lock( &mutex_done );
  done++;
  pthread_cond_signal( &cond_done );
  pthread_mutex_unlock(&mutex_done);
  
  pthread_mutex_lock(&mutex_step);
  while( step != stepnum ){ // this might be unsafe
    pthread_cond_wait( &cond_step, &mutex_step );
  }
  pthread_mutex_unlock(&mutex_step);
  
}

/*
Function: SyncWait
Purpose: Waits for every process to be done step.

Params:
nextstep - when not distributed, denotes the next step num. in the process.
*/
void Uni::SyncWait(int nextstep){
  pthread_mutex_lock(&mutex_done);
  while(done < numthreads){
    pthread_cond_wait(&cond_done, &mutex_done);
  }
  done = 0;
  pthread_mutex_unlock(&mutex_done);

  char* buffer;

  #if DISTRIBT
  if(step >= 0) 
  {
    // Done Grabbing Robot array
    if (step == 0)
    {
      _network.sendMessage("DGR", sv_con_socket);
    }
    // Done Updating Pose
    else if (step == 1)
    {
      _network.sendMessage("DUP", sv_con_socket);    
    }
    // Done Updating Sensor
    else if (step == 2)
    {
      _network.sendMessage("DUS", sv_con_socket);       
    }
    // Done Boundary Traversals
    else if (step == 3)
    {
      _network.sendMessage("DBT", sv_con_socket);       
    }

    buffer = _network.rcvMessage(sv_con_socket);
  }
  #endif

  pthread_mutex_lock(&mutex_step);

  #if DISTRIBT
  if(step >= 0) 
  {
    // Grab Robot Array
    if (strcmp(buffer, "GRA\n") == 0)
    {
      step = 0;
    }

    // Update Pose
    if (strcmp(buffer, "UPE\n") == 0)
    {
      step = 1;
    }

    // Update Sensor
    if (strcmp(buffer, "USN\n") == 0)
    {
      step = 2;
    }    

    // Boundary Traversals
    if (strcmp(buffer, "UBT\n") == 0)
    {
      step = 3;
    }    
  }
  #endif

  #if !DISTRIBT
  step = nextstep;
  #endif

  pthread_cond_broadcast(&cond_step);
  pthread_mutex_unlock(&mutex_step);

  #if DISTRIBT
  if(step >= 0) {
    free(buffer);
  }
  #endif
}

/*
Function: Run
Purpose: Sets the universe in motion.
*/
void Uni::Run()
{
  FOR_EACH( r, population ){ // initialize cells
    r->UpdateCell();
  }
  firstUpdateCell = false;
#if GRAPHICS
  glutMainLoop();
#else
  while( 1 )
    Uni::UpdateAll();
#endif
}

//////////////////
// ** ROBOTS ** //
//////////////////

/*
Function: UpdatePose
Purpose: Updates the position of each robot.
*/
void Robot::UpdatePose()
{
  // move according to the current speed
  double dx = speed[0] * cos(pose[2]);
  double dy = speed[0] * sin(pose[2]);;
  double da = speed[1];
  
  pose[0] = DistanceNormalize( pose[0] + dx );
  pose[1] = DistanceNormalize( pose[1] + dy );
  pose[2] = AngleNormalize( pose[2] + da );
  
  if (cell == NULL)
  {
    // doesn't know what cell it's in
    UpdateCell();
  }

  else if(!((pose[0] > cell->left) &&
            (pose[0] < cell->right) &&
            (pose[1] < cell->top) &&
            (pose[1] > cell->bottom)))
  {
    // loop through all of the robots in this cell, and remove this one.
    int i;

    pthread_mutex_t * mutex = &(cell->mutex_cellpop);
    pthread_mutex_lock(mutex);

    for (i=0;i<cell->cellpop.size(); i++)
    {
      if(cell->cellpop[i] == this)
      {
        cell->cellpop.erase(cell->cellpop.begin() + i); // remove from cell we are departing (VECTOR)
        break; // quit loop early
      }
    }
    
    pthread_mutex_unlock(mutex);
    UpdateCell();
  }
}

/*
Function: UpdateCell
Purpose: Handles the link between cells and robots, as well as deals with robots
that move out of a cell, and robots that are remote.
*/
void Robot::UpdateCell()
{
  double cellsize = worldsize/matrix_size;
  int cx = (int) floor(pose[0] / cellsize);
  int cy = (int) floor(pose[1] / cellsize);
  
  pthread_mutex_t * mutex = &(cellgrid[cx][cy].mutex_cellpop);
  pthread_mutex_lock(mutex);
  cellgrid[cx][cy].cellpop.push_back(this);
  cell = &(cellgrid[cx][cy]);
  pthread_mutex_unlock(mutex);

  if(!remote){
    if(gridset[cx][cy] == false){
      pthread_mutex_lock(&mutex_addingUnusedBot);
      if(firstUpdateCell){
        unused=true;
        _availableBots.push_back(this); // add to the vector of unused bots
      }else{
        // this is on a different host, queue up the things
        Uni::QueueLeavingRobot(this);
      }
      pthread_mutex_unlock(&mutex_addingUnusedBot);
    }
  }
}

/*
Function: SetCell
Purpose: Sets up the link between a cell and a robot.

Params:
cx - the x coordinate of the cell
cy - the y coordinate of the cell
*/
void Robot::SetCell(int cx, int cy)
{
  pthread_mutex_t * mutex = &(cellgrid[cx][cy].mutex_cellpop);
  pthread_mutex_lock(mutex);

  cellgrid[cx][cy].cellpop.push_back(this);
  cell = &(cellgrid[cx][cy]);

  pthread_mutex_unlock(mutex);
}

/*
Function: UpdateSensor
Purpose: Updates the sensor of each robot.  This is very complicated.  Read the
internal comments to get a sense of what this function does.
*/
void Robot::UpdateSensor()
{
  double radians_per_pixel = fov / (double)pixel_count;
  
  double halfworld = worldsize * 0.5;
  #if DISTRIBT
  if(gridset[this->cell->cx][this->cell->cy] == false){
    return;
  }
  #endif
  
  // initialize pixels vector
  FOR_EACH( it, pixels )
  {
    it->range = Robot::range; // maximum range
    it->robot = NULL; // nothing detected
  }
  
  //find a bounding box around this robot.
  BasicBoundingBox();
  
  // find which cells this bounding box is within
  std::vector<Cell*> cells;
  CellsInBoundingBox(this, &cells);

  // check every robot in these cells to see if it is detected
  int n = 0;
  FOR_EACH(cell, cells)
  {
    #if DISTRIBT
    int x = (*cell)->cx;
    int y = (*cell)->cy;

    // We do not own this cell, so we need to get its information.
    if (gridset[x][y] == false)
    {
      pthread_mutex_t * querymutex = &((*cell)->mutex_cellquery);
      // We have not talked to the other universe to get
      // its information about this cell.
      pthread_mutex_lock(querymutex);
      if (_unownedCells[x][y] == false)
      {
        pthread_mutex_lock(&Uni::mutex_doingQueryRemoteCell);
        howmanyhuhs++;
        Uni::QueryRemoteCell(*cell, x, y);
        pthread_mutex_unlock(&Uni::mutex_doingQueryRemoteCell);
      }
      pthread_mutex_unlock(querymutex);
    }
    #endif

  FOR_EACH( it, (*cell)->cellpop )
    {
      n++;
      Robot* other = *it;
      
      // discard if it's the same robot
      if( other == this )
        continue;
      
      // discard if it's out of range. We put off computing the
      // hypotenuse as long as we can, as it's relatively expensive.
      
      double dx = other->pose[0] - pose[0];
      
      // wrap around torus
      if( dx > halfworld )
        dx -= worldsize;
      else if( dx < -halfworld )
        dx += worldsize;
      
      if( fabs(dx) > Robot::range )
        continue; // out of range
      
      double dy = other->pose[1] - pose[1];
      
      // wrap around torus
      if( dy > halfworld )
        dy -= worldsize;
      else if( dy < -halfworld )
        dy += worldsize;
      
      if( fabs(dy) > Robot::range )
        continue; // out of range
      
      double range = hypot( dx, dy );
      if( range > Robot::range )
        continue;
      
      // discard if it's out of field of view
      double absolute_heading = atan2( dy, dx );
      double relative_heading = AngleNormalize((absolute_heading - pose[2]) );
      if( fabs(relative_heading) > fov/2.0   )
        continue;
      
      // find which pixel it falls in
      int pixel = floor( relative_heading / radians_per_pixel );
      pixel += pixel_count / 2;
      pixel %= pixel_count;
      
      assert( pixel >= 0 );
      assert( pixel < (int)pixel_count );
      
      // discard if we've seen something closer in this pixel already.
      if( pixels[pixel].range < range)
        continue;
      
      // if we made it here, we see this other robot in this pixel.
      pixels[pixel].range = range;
      pixels[pixel].robot = other;
    }
  }
}

/*
!!!! TO-DO: THIS FUNCTION STILL DOESN'T WORK PROPERLY !!!!

Function: FovBoundingBox
Purpose: Gets a bounding box for a robot based on its range and field of view.
*/
void Robot::FovBoundingBox()
{
  // construct a bounding box of the relevant area.
  std::vector<double> xa;
  std::vector<double> ya;
  
  xa.reserve(8);
  ya.reserve(8);
  
  // 0 degrees, straight ahead.
  xa.push_back(pose[0] + (range * cos(pose[2])));
  ya.push_back(pose[1] + (range * sin(pose[2])));

  // edges of the fov
  double halffov = fov/2.0;
  // positive fov
  xa.push_back(pose[0] + (range * cos(pose[2] + halffov )));
  ya.push_back(pose[1] + (range * sin(pose[2] + halffov )));

  // negative fov
  xa.push_back(pose[0] + (range * cos(pose[2] - halffov )));
  ya.push_back(pose[1] + (range * sin(pose[2] - halffov )));

  // contains 0 degrees
  if ((AngleNormalize(pose[2] + halffov) >= 0) && (AngleNormalize(pose[2] - halffov) <= 0))
  {
    // add points at 90 degrees
    xa.push_back(pose[0] + range);
    ya.push_back(pose[1]);
  }

  // greater than 90 degrees
  if ((AngleNormalize(pose[2] + halffov - (M_PI/2.0)) >= 0) && (AngleNormalize(pose[2] - halffov - (M_PI/2.0)) <= 0))
  {
    // add points at 90 degrees
    xa.push_back(pose[0]);
    ya.push_back(pose[1] + range);
  }
  
  // greater than 180 degrees
  if ((AngleNormalize(pose[2] + halffov - M_PI) >= 0) && (AngleNormalize(pose[2] - halffov - M_PI) <= 0))
  {
    // add points at 180 degrees
    xa.push_back(pose[0] - range);
    ya.push_back(pose[1]);
  }
  
  // contains 270 degrees
  if ((AngleNormalize(pose[2] + halffov - (3*M_PI/2.0)) >= 0 && (AngleNormalize(pose[2] - halffov - (3*M_PI/2.0)) <= 0)))
  {
    // add points at 270 degrees
    xa.push_back(pose[0]);
    ya.push_back(pose[1] - range);
  }
  
  double minx,maxx,miny,maxy;
  minx = pose[0];
  maxx = pose[0];
  miny = pose[1];
  maxy = pose[1];
  
  std::vector<double>::iterator Iterator;

  // x
  for (Iterator = xa.begin(); Iterator != xa.end(); Iterator++)
  {
    if (*Iterator > maxx)
    {
      maxx = *Iterator;      
    }

    if (*Iterator < minx)
    {
      minx = *Iterator;      
    }
  }

  // y
  for (Iterator = ya.begin(); Iterator != ya.end(); Iterator++)
  {
    if (*Iterator > maxy)
    {
      maxy = *Iterator;
    }
    if (*Iterator < miny)
    {
      miny = *Iterator;      
    }
  }
  
  fovbox[0]=maxx;
  fovbox[1]=maxy;
  fovbox[2]=minx;
  fovbox[3]=miny;
}

/*
Function: BasicBoundingBox
Purpose: Gets the bounding box for a robot based only on range.
*/
void Robot::BasicBoundingBox(){
  fovbox[0] = pose[0] + range;
  fovbox[1] = pose[1] + range;
  fovbox[2] = pose[0] - range;
  fovbox[3] = pose[1] - range;
}

/*
Function: Robot::Draw
Purpose: Draw a robot.
*/
void Robot::Draw() const
{
#if GRAPHICS
  //draw bounding box
  if(unused){
    return;
  }
  if(boundingbox){
    glColor4f(0,0,.5,.8);
    glBegin( GL_LINE_LOOP );
    glVertex2f( fovbox[2], fovbox[3] );
    glVertex2f( fovbox[0], fovbox[3] );
    glVertex2f( fovbox[0], fovbox[1] );
    glVertex2f( fovbox[2], fovbox[1] );
    glEnd();
  }
  
  //end draw bounding box
  glPushMatrix();
  glTranslatef( pose[0], pose[1], 0 );
  glRotatef( rtod(pose[2]), 0,0,1 );
  
  if(remote){
    glColor3ub(1,0,1);
  }
  else{
    glColor3ub( color[0], color[1], color[2] );
  }
  
  // draw the pre-compiled triangle for a body
  glCallList(displaylist);
  
  if( show_data )
  {
    // render the sensors
    double rads_per_pixel = fov / (double)pixel_count;
    glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );
    
    for( unsigned int p=0; p<pixel_count; p++ )
    {
      double angle = -fov/2.0 + (p+0.5) * rads_per_pixel;
      double dx1 = pixels[p].range * cos(angle+rads_per_pixel/2.0);
      double dy1 = pixels[p].range * sin(angle+rads_per_pixel/2.0);
      double dx2 = pixels[p].range * cos(angle-rads_per_pixel/2.0);
      double dy2 = pixels[p].range * sin(angle-rads_per_pixel/2.0);
      
      glColor4f( 1,0,0, pixels[p].robot ? 0.2 : 0.05 );
      
      glBegin( GL_POLYGON );
      glVertex2f( 0,0 );
      glVertex2f( dx1, dy1 );
      glVertex2f( dx2, dy2 );
      glEnd();
    }
  }
  
  glPopMatrix();
#endif // GRAPHICS
}

////////////////
// ** CELL ** //
////////////////

/*
Function: Cell::Draw
Purpose: Draw a cell.
*/
void Cell::Draw() const
{
  #if GRAPHICS
  glPushMatrix();

  if(cellpop.size() == 0)
  {
    glColor4f( 1, 1, 1, 0.75);    
  }

  else 
  {
    //HSV in float color sans S and V
    //Using a switch containing ranges, a single floating point value roughly based on cell population
    //is turned into a full color spectrum.
    float hsvhue = cellpop.size()/((float)population.size()/((float)matrix_size_sq/2));
    int hsvswitch = floor(hsvhue * 6);
    
    switch (hsvswitch)
    {
      case 0: //0-.16
        glColor4f(0, 0, hsvhue/0.16, 0.75*(hsvhue/0.16));
        break;
      case 1: //.16-.33
        glColor4f(0, (hsvhue-0.16)/0.16, 1, 0.75);
        break;
      case 2: //.33-.5
        glColor4f(0, 1, (0.5-hsvhue)/0.16, 0.75);
        break;
      case 3: //.5-.66
        glColor4f((hsvhue-0.5)/0.16, 1, 0, 0.75);
        break;
      case 4: //.66-.72
        glColor4f(1, (0.72-hsvhue)/0.16, 0, 0.75);
        break;
      case 5: //.72-1
        glColor4f(1, 0, (hsvhue-0.72)/0.16, 0.75);
        break;
      case 6:
      case 7:
        //1-1.16
        glColor4f(0.33/(hsvhue-1.0000000), 0, 0.33/(hsvhue-1.0000000), 0.75);
        break;
      default:
        glColor4f( 0, 0, 0, 0.75);
        break;
    }
  }
  
    
  glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );
  glBegin( GL_POLYGON );
  glVertex2f(left, top);
  glVertex2f(right, top);
  glVertex2f(right, bottom);
  glVertex2f(left, bottom);
  glEnd();
  glPopMatrix();
  #endif
}

//////////////////////
// ** NETWORKING ** //
//////////////////////

/*
Function: error
Purpose: Throws a perror and exits the program.

Params: 
msg - the message we want to throw
*/
void Network::error(const char *msg)
{
  perror(msg);
  exit(0);
}

/*
Function: getSocket
Purpose: Checks if there is an open socket to a client.  If so,
it returns the socket.  If not, it calls the function to create
it and returns the new socket.

Params: 
rem_address - the IP address of the remote client
*/
connection* Network::getSocket(char* rem_address)
{

  FOR_EACH( c, connections )
  {
    if(strcmp(c->ip_addr.c_str(), rem_address) == 0)
    {
      return &(*c);
    }
  }
  fprintf(stderr, "num open sockets: %d\n", connections.size());

  return openClientSocket(rem_address);
}

/*
Function: openClientSocket
Purpose: This function opens a socket to a remote client.

Params: 
rem_address - the IP address of the remote client
*/
connection* Network::openClientSocket(char* rem_address)
{
  int sockfd, portno;
  struct sockaddr_in serv_addr;
  struct hostent *server;

  // Create the Socket  
  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  int optval = 1;
  setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof optval);

  if (sockfd < 0)
  {
    error("ERROR opening socket");
  }

  // Server and Port to Connect to
  server = gethostbyname(rem_address);
  portno = atoi(Uni::port);

  if (server == NULL) 
  {
    error("ERROR no such host");
  }

  // Clear out our options structure.
  bzero((char *) &serv_addr, sizeof(serv_addr));

  // Serv_addr options
  serv_addr.sin_family = AF_INET;
  bcopy((char *)server->h_addr_list[0], (char *)&serv_addr.sin_addr.s_addr, server->h_length);
  serv_addr.sin_port = htons(portno);

  // Connect to our server
  if (connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0)
  {
    error("ERROR connecting"); 
  }

  connections.emplace_back(connection{ std::string(rem_address), sockfd, PTHREAD_MUTEX_INITIALIZER });

  return &(connections.back());
}

/*
Function: openSocket
Purpose: Opens a socket to the server.

Params: 
rem_address - the remote ip address
port - the remote server's port
*/
int Network::openSocket(char* rem_address, char* port)
{
  int sockfd, portno;
  struct sockaddr_in serv_addr;
  struct hostent *server;

  // Create the Socket  
  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  int optval = 1;
  setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof optval);

  if (sockfd < 0)
  {
    error("ERROR opening socket");
  }

  // Server and Port to Connect to
  server = gethostbyname(rem_address);
  portno = atoi(port);

  if (server == NULL) 
  {
    error("ERROR no such host");
  }

  // Clear out our options structure.
  bzero((char *) &serv_addr, sizeof(serv_addr));

  // Serv_addr options
  serv_addr.sin_family = AF_INET;
  bcopy((char *)server->h_addr_list[0], (char *)&serv_addr.sin_addr.s_addr, server->h_length);
  serv_addr.sin_port = htons(portno);

  // Connect to our server
  if (connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0)
  {
    error("ERROR connecting"); 
  }

  return sockfd;
}

/*
Function: startServer
Purpose: This starts a server, creates a socket, and then for every incoming 
connection, starts a new socket which it does some processing on, and then
closes it.

Params: 
port - the port you want to start the server on
*/
int Network::startServer(char* port)
{
  int sockfd, newsockfd, portno;
  struct sockaddr_in serv_addr;

  // Create our socket
  sockfd = socket(AF_INET, SOCK_STREAM, 0);

  if (sockfd < 0)
  {
    return -1; 
  }

  // Clear out serv_addr (our server options list structure)
  bzero((char *) &serv_addr, sizeof(serv_addr));

  // Adding the options
  portno = atoi(port);  // SET PORT NUMBER FROM ARGS
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = INADDR_ANY;
  serv_addr.sin_port = htons(portno);

  // Bind our socket to a port
  if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
  {
    return -1;  
  } 

  return sockfd;
}

/*
Function: listenForConnections
Purpose: Starting point for a thread that processes incoming connections one by
one and acts on their commands.

Params: 
sockfdv - the socket file descriptor for the listening socket
*/
void* Network::listenForConnections(void* sockfdv)
{

  int* sockfd = (int*) sockfdv;
  socklen_t clilen;
  struct sockaddr_in cli_addr;
  int newsockfd;

  // Listen for connections
  listen(*sockfd, 10000); // Max of 5 Connections
  clilen = sizeof(cli_addr);
  std::vector<pthread_t> serverthreads;

  int i;
  for(i=0; i<25; i++){ // Create worker threads

    pthread_t newthread;
    pthread_create(&newthread, NULL, Network::handleConnection, NULL);
    serverthreads.push_back(newthread);

  }
    while (1)
    {
        newsockfd = accept(*sockfd, (struct sockaddr *) &cli_addr, &clilen);
        pthread_mutex_lock( &mutex_clientqueue );
        clientqueue.push_back(newsockfd);
#if NETDEBUG
        fprintf(stderr, "queue size: %d\n", clientqueue.size());
#endif
        pthread_cond_signal( &cond_clientqueue );
        pthread_mutex_unlock( &mutex_clientqueue );
    } /* end of while */
}

/*
Function: handleConnection
Purpose: This is the function that takes in the a connection and handles
any command sent from the remote client.

Params: 
newsockfdvoid - A void pointer to the socket id.
*/
void* Network::handleConnection(void* newsockfdvoid){
	int newsockfd = 0;
  bool open;
	

	while(1){ // 
    pthread_mutex_lock( &mutex_clientqueue );

    while(clientqueue.size() == 0){
      pthread_cond_wait( &cond_clientqueue, &mutex_clientqueue );
    }
    open = true;

    char* buff = (char*) malloc(sizeof (char) * 256);

    newsockfd = clientqueue.back();
    clientqueue.pop_back();
    pthread_mutex_unlock( &mutex_clientqueue );

    while(open){
      if (newsockfd < 0)
      {
        error("ERROR on accept");
        fprintf(stderr,"ea");
      }

      char* buffer = rcvMessage(newsockfd);

      bzero(buff, (sizeof (char) * 256));
      strncpy(buff,buffer,255);


      char* cmd;
      char* strtokpos;

      cmd = strtok_r(buff," ", &strtokpos);

      if ((cmd == NULL) || (strncmp(cmd, "BYE", 3) == 0)){
        closeSocket(newsockfd);
        open = false;
        break;
      }

      else if (strncmp(cmd, "HUH", 3) == 0)
      {
        cmd = strtok_r(NULL," ", &strtokpos);
        int x = atoi(cmd);
        cmd = strtok_r(NULL," ", &strtokpos);
        int y = atoi(cmd);
          #if NETDEBUG
            fprintf(stderr, "received HUH: '%s':", buffer);
          #endif

        char* posesbuf = Uni::CellToBuffer(x,y);
        int err = sendMessage(posesbuf, newsockfd);
        //fprintf(stderr, "responding with %s.\n", posesbuf);
        free(posesbuf);

        if(err != 0){
          fprintf(stderr, "error sending large message %d", err);
        }
      }

      else if (strncmp(cmd, "NB", 2) == 0)
      {
        strncpy(buff,buffer,255);
        int err = sendMessage("OK",newsockfd);
        Uni::QueueNewRobot(buff);
      }

      else if (strncmp(cmd, "CELLPOPALL", 10) == 0)
      {
        bool listening = true; //set false to break out of loop
        while(listening)
        {
          //probably want some kind of nonblocking recv here to control
          // this client is subscribing to cellpop updates.
          pthread_mutex_lock(&mutex_cellpopall);
          pthread_cond_wait( &cond_cellpopall, &mutex_cellpopall ); // wait for main loop to give us the ok.
          pthread_mutex_unlock(&mutex_cellpopall);

          char* buf = (char*) malloc (sizeof (char) * 256);
          // loop through owned cells and tell the client
          for (int i = 0; i < matrix_size; i++)
          {
            for (int j = 0; j < matrix_size; j++)
            {
              Cell c = cellgrid[i][j];
              if (gridset[i][j] == true) // we own this cell
              {
                bzero(buf, sizeof (char) * 256);
                sprintf(buf, "%d %d %s", i, j, Uni::getCellPopulation(i,j));
                int err = sendMessage(buf,newsockfd);
              }
            }
          }
          free(buf);
        }
      }
      else if (strncmp(cmd, "CELLPOP", 7) == 0)
      {
        cmd = strtok_r(NULL," ", &strtokpos);
        int x = atoi(cmd);
        cmd = strtok_r(NULL," ", &strtokpos);
        int y = atoi(cmd);

        char* popMesg = Uni::getCellPopulation(x,y);
        int err = sendMessage(popMesg,newsockfd);
        free(popMesg);
      }

      // Deallocate Pose Buffer
      free(buffer);

    } // done with this connection

		free(buff);
  } // outer loop for thread worker
}

/*
Function: rcvMessage
Purpose: Grabs the message from the socket and returns it.  Don't forget to 
deallocate the buffer when done.

Params: 
sockfd - the socket file descriptor
*/
char* Network::rcvMessage(int sockfd)
{
  size_t err;
  int stringlen_i;

  // get the number of digits in size
  char* numdigits_s = (char*) malloc(sizeof (char) * 2); // allocate buf of two characters
  bzero(numdigits_s,sizeof(char) * 2);
  err = recv(sockfd, numdigits_s, 1, 0); // read one character
  int numdigits_i = atoi(numdigits_s);

  char* stringlen_s = (char*) malloc (sizeof (char) * (numdigits_i+1)); // allocate buffer to hold the size of the message
  bzero(stringlen_s,sizeof(char) * (numdigits_i+1));
  err = recv(sockfd,stringlen_s,numdigits_i,0); // read numdigits

  stringlen_i = atoi(stringlen_s);

  char* buffer = (char*) malloc (sizeof (char) * (stringlen_i + 1));
  bzero(buffer,sizeof(char) * (stringlen_i+1));

  char* buffpos = buffer;
  size_t remaining = stringlen_i;
  while(remaining >0){
    err = recv(sockfd,buffpos,remaining,0);
    if(err < 0)
    {
      error("ERROR reading from socket");  
      return NULL;
    }
    remaining -= err;
    buffpos += err;

  }

  free(numdigits_s);
  free(stringlen_s);

  #if NETDEBUG
	printf("rcv(%d):%s\n",sockfd,buffer);
  #endif

  return buffer;
}

/*
Function: sendMessage
Purpose: Takes in a message and sends it over the socket

Params: 
mesg - the message to send
sockfd - the socket file descriptor
*/
int Network::sendMessage(char* mesg, int sockfd)
{
  size_t err;

  int mlen = strlen(mesg);
  char mlen_s[10];
  sprintf(mlen_s, "%d", mlen);
  int numdigits = strlen(mlen_s);
  if(numdigits > 10)
  {
    fprintf(stderr, "trying to send a buffer that is way too big\n");
  }

  char* buffer = (char*) malloc (sizeof (char) * (mlen + numdigits + 2)); // +2: one for prefix number, one to ensure space for null at end
  bzero(buffer, (sizeof (char) * (mlen + numdigits + 2)));


  sprintf(buffer, "%d%s%s", numdigits, mlen_s, mesg);    

  #if NETDEBUG
    printf("snd(%d):%s\n", sockfd, buffer);
  #endif

  char* buffpos = buffer;
  size_t remaining = (mlen+numdigits+1);
  while(remaining > 0){
    err = write(sockfd,buffpos,remaining);
    if (err < 0)
    {
      error("ERROR writing to socket");
      return -1;
    }
    remaining -= err;
    buffpos += err;

  }
  free(buffer);

  return 0;
}


/*
Function: handshake
Purpose: Does initial contact with server.

Params: 
sockfd - the socket file descriptor
buffer - the buffer for commands
*/
int Network::handshake(int sockid)
{
  char* buffer = rcvMessage(sockid);

  if (strcmp(buffer, "SUP.\n") != 0)
  {
    fprintf(stderr, "NO SUP");
    return -1;   
  }

  free(buffer);
  sendMessage("id uni", sockid);
  buffer = rcvMessage(sockid);

  if (buffer[0] != '+')
  {
    fprintf(stderr, "NO PLUS, GOT %s", buffer);
    return -1;   
  }

  free(buffer);
  buffer = rcvMessage(sockid);  

  if (strcmp(buffer, "CELLSASSIGNED\n") != 0)
  {
    fprintf(stderr, "NO CELLSASSIGNED. GOT %s", buffer);
    return -1;
  }

  sendMessage("cells", sockid);  
  free(buffer);
  buffer = rcvMessage(sockid);
  free(buffer);

  return 0;
}

/*
Function: closeSocket
Purpose: It closes a socket.

Params: 
sockfd - the socket file descriptor
*/
void Network::closeSocket(int sockfd)
{
  close(sockfd);
}
